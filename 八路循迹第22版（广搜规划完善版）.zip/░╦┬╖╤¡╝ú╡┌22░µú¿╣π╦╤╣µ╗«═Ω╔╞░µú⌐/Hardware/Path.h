#ifndef __PATH_H
#define __PATH_H


void Line_Repair(void);////����ѭ��
void Path_test(void) ;
void Car_Strike(void);
void Car_Left_Turn(void);	//ԭ����ת
void Clear_Flag(void);
void Unusual_Status(void);
extern unsigned char Node_Num;

extern unsigned int Speed;

extern unsigned char Turn_Flag;

extern unsigned int Path;			//��·��־λ

#endif
