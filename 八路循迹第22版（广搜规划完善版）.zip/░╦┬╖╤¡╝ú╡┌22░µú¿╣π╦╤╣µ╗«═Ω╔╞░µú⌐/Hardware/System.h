#ifndef __SYSTEM_H
#define __SYSTEM_H


#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Motor.h"
#include "Path.h"
#include "Key.h"
#include "LED.h"
#include "Timer.h"
#include "Tracking.h"
#include "Path_plaing.h"
#include "Serial.h"
#include "OLED.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>


#define Curve_Speed 45	//ת����ٶ�
#define Speed_Cut 30	//ʶ�����һ��·�ε��ٶ�


extern unsigned char Decelerate_Flag;		//���ٱ�־λ
extern unsigned char LED_Flag;
extern unsigned char Buzzer_Flag;
extern unsigned char Now_condition;
extern unsigned char Camp_Flag;
extern unsigned char Interrupt_Flag;
extern unsigned char Receive_State;
extern unsigned char Treasure_Num;
extern unsigned char Dist_Flag;
extern unsigned char Dist_ON_Flag;
extern unsigned char Ending_Flag;
extern unsigned int Dist_mm;

void System_Init(void);
void OpenMV_Reset(void);

#endif


