#ifndef __MOTOR_H
#define __MOTOR_H

#define  Motor_L1_Go()	   {GPIO_SetBits(GPIOA, GPIO_Pin_0); GPIO_ResetBits(GPIOB,GPIO_Pin_5);}

#define  Motor_L1_Back()	{GPIO_ResetBits(GPIOA, GPIO_Pin_0);GPIO_SetBits(GPIOB,GPIO_Pin_5);}

#define  Motor_L1_Stop()	{GPIO_ResetBits(GPIOA, GPIO_Pin_0);GPIO_ResetBits(GPIOB,GPIO_Pin_5);}

							
#define  Motor_R1_Go()	   {GPIO_SetBits(GPIOD, GPIO_Pin_10); GPIO_ResetBits(GPIOD,GPIO_Pin_9);}

#define  Motor_R1_Back()	{GPIO_ResetBits(GPIOD, GPIO_Pin_10);GPIO_SetBits(GPIOD,GPIO_Pin_9);}

#define  Motor_R1_Stop()	{GPIO_ResetBits(GPIOD, GPIO_Pin_10);GPIO_ResetBits(GPIOD,GPIO_Pin_9);}
							

#define  Motor_L2_Go()	{   GPIO_SetBits(GPIOA, GPIO_Pin_5); GPIO_ResetBits(GPIOA,GPIO_Pin_4);}

#define  Motor_L2_Back()	{GPIO_ResetBits(GPIOA, GPIO_Pin_5);GPIO_SetBits(GPIOA,GPIO_Pin_4);}

#define  Motor_L2_Stop()	{GPIO_ResetBits(GPIOA, GPIO_Pin_5);GPIO_ResetBits(GPIOA,GPIO_Pin_4);}


#define  Motor_R2_Go()	{  GPIO_SetBits(GPIOB, GPIO_Pin_6); GPIO_ResetBits(GPIOB,GPIO_Pin_7);}

#define  Motor_R2_Back()	{GPIO_ResetBits(GPIOB, GPIO_Pin_6);GPIO_SetBits(GPIOB,GPIO_Pin_7);}

#define  Motor_R2_Stop()	{GPIO_ResetBits(GPIOB, GPIO_Pin_6);GPIO_ResetBits(GPIOB,GPIO_Pin_7);}

void PWM_Init(void);
void Motor_Init(void);


void Car_Run(int Speed);
void Car_Left(int Speed);
void Car_Right(int Speed);
void Car_Right_angle(int Speed);
void Car_Left_angle(int Speed);
void Car_Stop(void);
void Car_Back(int Speed);

void Motor_L1_SetSpeed(int8_t Speed);
void Motor_L2_SetSpeed(int8_t Speed);
void Motor_R1_SetSpeed(int8_t Speed);
void Motor_R2_SetSpeed(int8_t Speed);

void Repair_Run(int L_Speed,int R_Speed);

#endif
