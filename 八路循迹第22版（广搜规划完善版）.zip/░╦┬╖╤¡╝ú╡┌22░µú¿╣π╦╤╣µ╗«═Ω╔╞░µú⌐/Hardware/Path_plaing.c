#include "stm32f10x.h"                  // Device header
#include "stdio.h"
#include "Path_plaing.h"
#include "Serial.h"
 //������ά����ģ���Թ�
int  map[21][21];
int  map_original[21][21];
int  BFS_map_original[21][21];
int sequence;
// OpenMv 8�����ص�[[4, 2], [5, 3], [9, 3], [1, 4], [8, 5], [0, 6], [4, 6], [5, 7], [9, 0]] 9
int OpenMv_Target1[2]={0,6};
int OpenMv_Target2[2]={4,9};
int OpenMv_Target3[2]={5,7};
int OpenMv_Target4[2]={9,9};//��
int OpenMv_Target5[2]={9,3};
int OpenMv_Target6[2]={5,0};
int OpenMv_Target7[2]={4,2};
int OpenMv_Target8[2]={0,0};
//���б��ص���λ
int Arrange_Treasure_Point = 0;
// stm32���ص���λ
int	Stm32_Target1[2];
int Stm32_Target2[2];
int Stm32_Target3[2];
int Stm32_Target4[2];
int Stm32_Target5[2];
int Stm32_Target6[2];
int Stm32_Target7[2];
int Stm32_Target8[2];
int Test1[2]={7,11};
int Test2[2]={3,13};
//14����ʱ�洢���ص�
int	Stm32_Target1_Arrange[2];
int Stm32_Target2_Arrange[2];
int Stm32_Target3_Arrange[2];
int Stm32_Target4_Arrange[2];
int Stm32_Target5_Arrange[2];
int Stm32_Target6_Arrange[2];
int Stm32_Target7_Arrange[2];
int Stm32_Target8_Arrange[2];
int Stm32_Target9_Arrange[2];
int Stm32_Target10_Arrange[2];
int Stm32_Target11_Arrange[2];
int Stm32_Target12_Arrange[2];
int Stm32_Target13_Arrange[2];
int Stm32_Target14_Arrange[2];
int Stm32_Target15_Arrange[2];
int Stm32_Target16_Arrange[2];
int Stm32_Target17_Arrange[2];
int Stm32_Target18_Arrange[2];
int Stm32_Target19_Arrange[2];
int Stm32_Target20_Arrange[2];
int Stm32_Target21_Arrange[2];
int Stm32_Target22_Arrange[2];
int Stm32_Target23_Arrange[2];
int Stm32_Target24_Arrange[2];
int Stm32_Target_Arrange_temp[48];
int Stm32_Target_Arrange_temp_output[28];
int Stm32_Target_Arrange_temp_output_delet_point[16];
int Stm32_Target_Arrange_temp_output_delet_point2[16];
int Stm32_Target_Arrange_temp_output_delet_point3[16];
//���������յ�
int Begin_point[2]={19,1};
int Eeding_point[2]={1,19};
//9����·
int path=0;
//��̲���
int mileage;
int Total_mileage;
//�ŵ���Ҫ����
int first_condition = 0;
int second_condition = 0;
int third_condition = 0;
int red_true_num = 0;
int red_false_num = 0;
int blue_true_num = 0;
int blue_false_num = 0;
int normal=1;
int ending = 0;
// 9����·�Ľ��洢����
//ת��洢���� 0�����ޣ�������;1����ǰ����2������ת��3������ת��
int Turn_temp[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp1[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp2[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp3[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp4[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp5[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp6[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp7[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp8[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp9[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int Turn_temp_break[30]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


/*�ŵ�·���滮
������ڣ�1.��· 
          2.��ǰʶ��·����ɫ����0��1����·Ϊ5��
		    
		    û��ʶ�𵽣�0
		    ���棺1
			��٣�2
			���棺3
			���٣�4
          3.������ʲô��ɫ��
		    �췽��1
			������2
		  4.�Ƿ�Ϊ�жϣ�����㷢����
		    ������ʹ��1
			�жϣ�2
*/
void Plaing(int path,int now_condition,int Own_color,int dot)
{
	    if(path == 0)
		{
			mapping();
		}
	    //�жϱ�־λΪ2
		else if(dot == 2)	  
		{
			Total_break(path);	
		}
		else if(now_condition == 0 || normal == 2)
		{
			normal = 2;
			//ֹͣ�ŵ㣬��������־λ����쳣��־λ
			abnomal(path);
		}
		else if(dot == 1 && normal == 1 )	
	    Delete_point_Path_planning(path,now_condition,Own_color);
}

void mapping()
{
	 int i,j= 0;
				//ʹ��1��ʾǽ
				//������Ϊ1
				for ( i = 0; i < 21; i++)
				{
					map[0][i] = 1;
					map[20][i] = 1;
				}
				//������Ϊ1
				for ( i = 0; i < 21; i++)
				{
					map[i][0] = 1;
					map[i][20] = 1;
				}
				//����
				map[1][10] = 1;map[1][16] = 1;
				map[2][2] = 1;map[2][4] = 1;  map[2][5] = 1; map[2][5] = 1; map[2][6] = 1;map[2][8] = 1;map[2][10] = 1;map[2][12] = 1;map[2][13] = 1;map[2][14] = 1;map[2][16] = 1;map[2][18] = 1;map[2][19] = 1;
				map[3][2] = 1;map[3][4] = 1;map[3][8] = 1;map[3][14] = 1;map[3][16] = 1;
				map[4][2] = 1;map[4][3] = 1;map[4][4] = 1;map[4][6] = 1;map[4][7] = 1;map[4][8] = 1;map[4][10] = 1;map[4][11] = 1;map[4][12] = 1;map[4][14] = 1;map[4][16] = 1;map[4][17] = 1;map[4][18] = 1;
				map[5][2] = 1;map[5][3] = 1; map[5][8] = 1;map[5][14] = 1; map[5][16] = 1;
				map[6][1] = 1;map[6][2] = 1;map[6][4] = 1;map[6][6] = 1;map[6][8] = 1;map[6][9] = 1;map[6][10] = 1;map[6][11] = 1;map[6][12] = 1;map[6][14] = 1;map[6][15] = 1;map[6][16] = 1;map[6][18] = 1;map[6][19] = 1;
				map[7][4] = 1;map[7][6] = 1;map[7][12] = 1;map[7][18] = 1;
				map[8][2] = 1;map[8][3] = 1;map[8][4] = 1;map[8][6] = 1;map[8][8] = 1;map[8][9] = 1;map[8][10] = 1;map[8][11] = 1;map[8][12] = 1;map[8][13] = 1;map[8][14] = 1;map[8][16] = 1;map[8][17] = 1;map[8][18] = 1;
				map[9][2] = 1;map[9][6] = 1;
				map[10][1] = 1;map[10][2] = 1;map[10][3] = 1;map[10][4] = 1;map[10][5] = 1;map[10][6] = 1;map[10][8] = 1;map[10][9] = 1;map[10][10] = 1;map[10][11] = 1;map[10][12] = 1;map[10][14] = 1;map[10][15] = 1;map[10][16] = 1;map[10][17] = 1;map[10][18] = 1;map[10][19] = 1;
				map[11][14] = 1;map[11][18] = 1;
				map[12][2] = 1;map[12][3] = 1;map[12][4] = 1;map[12][6] = 1;map[12][7] = 1;map[12][8] = 1;map[12][9] = 1;map[12][10] = 1;map[12][11] = 1;map[12][12] = 1;map[12][14] = 1;map[12][16] = 1;map[12][17] = 1;map[12][18] = 1;
				map[13][2] = 1;map[13][8] = 1;map[13][14] = 1;map[13][16] = 1;
				map[14][1] = 1;map[14][2] = 1;map[14][4] = 1;map[14][5] = 1;map[14][6] = 1;map[14][8] = 1;map[14][9] = 1;map[14][10] = 1;map[14][11] = 1;map[14][12] = 1;map[14][14] = 1;map[14][16] = 1;map[14][18] = 1;map[14][19] = 1;
				map[15][4] = 1;map[15][6] = 1;map[15][12] = 1;map[15][16] = 1;map[15][18] = 1;
				map[16][2] = 1;map[16][3] = 1;map[16][4] = 1;map[16][6] = 1;map[16][8] = 1;map[16][9] = 1;map[16][10] = 1;map[16][12] = 1;map[16][13] = 1;map[16][14] = 1;map[16][16] = 1;map[16][17] = 1;map[16][18] = 1;
				map[17][4] = 1;map[17][6] = 1;map[17][12] = 1;map[17][16] = 1;map[17][18] = 1;
				map[18][1] = 1;map[18][2] = 1;map[18][4] = 1;map[18][6] = 1;map[18][7] = 1;map[18][8] = 1;map[18][10] = 1;map[18][12] = 1;map[18][14] = 1;map[18][15] = 1;map[18][16] = 1;map[18][18] = 1;
				map[19][4] = 1;map[19][10] = 1;
				 for (i = 0; i < 21; i++)
				{
					for (j = 0; j < 21; j++)
					{
						if(map[i][j]  != 1)
						{
							map[i][j]=0;
						}
					}
				}
				 //����ǰ��ͼ��ֵ����ʼ��ͼ
				 for (i = 0; i < 21; i++)
				{
					for (j = 0; j < 21; j++)
					{
					  map_original[i][j]= map[i][j];
					}
				}
				 //�����ռ���·�����
				  for (i = 0; i < 21; i++)
				{
					for (j = 0; j < 21; j++)
					{
					  BFS_map_original[i][j]= map[i][j];
					}
				}
				extract_Treasure_Point();
				Coordinate_point_arrangement();
				Go_through_all_the_points();
}
void Total_break(int path)
{
	if((0<path)&&(path<10))
	{
		switch(path)
		{
			case 1:
			Total_path_planning_break(Stm32_Target1,map);
			Path_planning_update();
			return;
			case 2:
			Total_path_planning_break(Stm32_Target2,map);
			Path_planning_update();
			return;
			case 3:
			Total_path_planning_break(Stm32_Target3,map);
			Path_planning_update();
			return;
			case 4:
			Total_path_planning_break(Stm32_Target4,map);
			Path_planning_update();
			return;
			case 5:
			Total_path_planning_break(Stm32_Target5,map);
			Path_planning_update();
			return;
			case 6:
			Total_path_planning_break(Stm32_Target6,map);
			Path_planning_update();
			return;
			case 7:
			Total_path_planning_break(Stm32_Target7,map);
			Path_planning_update();
			return;
			case 8:
			Total_path_planning_break(Stm32_Target8,map);
			Path_planning_update();
			return;
			case 9:
			Total_path_planning_break(Eeding_point,map);
			Path_planning_update();
			return;
		}
	}
}
void abnomal(int path)
{
	switch(path)
	{
		case 1:
		Total_path_planning_myself_ultimate(Begin_point,Stm32_Target1,map,1);
		Path_planning_update();
		return;
		case 2:
		Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
		Path_planning_update();
		return;
		case 3:
		Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
		Path_planning_update();
		return;
		case 4:
		Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
		Path_planning_update();
		return;
		case 5:
		Total_path_planning_myself_ultimate(Stm32_Target4,Stm32_Target5,map,5);
		Path_planning_update();
		return;
		case 6:
		Total_path_planning_myself_ultimate(Stm32_Target5,Stm32_Target6,map,6);
		Path_planning_update();
		return;
		case 7:
		Total_path_planning_myself_ultimate(Stm32_Target6,Stm32_Target7,map,7);
		Path_planning_update();
		return;
		case 8:
		Total_path_planning_myself_ultimate(Stm32_Target7,Stm32_Target8,map,8);
		Path_planning_update();
		return;
		case 9:
		Total_path_planning_myself_ultimate(Stm32_Target8,Eeding_point,map,9);
		Path_planning_update();
		return;
	}
}
void extract_Treasure_Point(void)
{
	int i;
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target1[1] = 2*OpenMv_Target1[i]+1;
		if(i==1)
		Stm32_Target1[0] = 2*OpenMv_Target1[i]+1;
	}
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target2[1] = 2*OpenMv_Target2[i]+1;
		if(i==1)
		Stm32_Target2[0] = 2*OpenMv_Target2[i]+1;
	}
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target3[1] = 2*OpenMv_Target3[i]+1;
		if(i==1)
		Stm32_Target3[0] = 2*OpenMv_Target3[i]+1;
	}
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target4[1] = 2*OpenMv_Target4[i]+1;
		if(i==1)
		Stm32_Target4[0] = 2*OpenMv_Target4[i]+1;
	}
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target5[1] = 2*OpenMv_Target5[i]+1;
		if(i==1)
		Stm32_Target5[0] = 2*OpenMv_Target5[i]+1;
	}
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target6[1] = 2*OpenMv_Target6[i]+1;
		if(i==1)
		Stm32_Target6[0] = 2*OpenMv_Target6[i]+1;
	}
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target7[1] = 2*OpenMv_Target7[i]+1;
		if(i==1)
		Stm32_Target7[0] = 2*OpenMv_Target7[i]+1;
	}
	for(i=0;i<2;i++)
	{
		if(i==0)
		Stm32_Target8[1] = 2*OpenMv_Target8[i]+1;
		if(i==1)
		Stm32_Target8[0] = 2*OpenMv_Target8[i]+1;
	}

}
void Coordinate_point_arrangement(void)
{
	int i,j;
	for(i=0;i<8;i++)
	{
		if(i==0)
		{
			if(Stm32_Target1[0] == 15 && Stm32_Target1[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target1[0] == 17 && Stm32_Target1[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target1[0] == 19 && Stm32_Target1[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target1[0] == 19 && Stm32_Target1[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target1[0] == 15 && Stm32_Target1[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target1[0] == 19 && Stm32_Target1[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target1[0] == 15 && Stm32_Target1[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target1[0] == 17 && Stm32_Target1[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target1[0] == 11 && Stm32_Target1[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target1[0] == 11 && Stm32_Target1[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target1[0] == 13 && Stm32_Target1[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target1[0] == 13 && Stm32_Target1[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target1[0] == 7 && Stm32_Target1[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target1[0] == 9 && Stm32_Target1[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target1[0] == 9 && Stm32_Target1[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target1[0] == 1 && Stm32_Target1[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target1[0] == 5 && Stm32_Target1[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target1[0] == 3 && Stm32_Target1[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target1[0] == 3 && Stm32_Target1[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target1[0] == 5 && Stm32_Target1[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target1[0] == 1 && Stm32_Target1[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target1[0] == 1 && Stm32_Target1[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target1[0] == 5 && Stm32_Target1[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target1[0] == 7 && Stm32_Target1[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}


		if(i==1)
		{
			if(Stm32_Target2[0] == 15 && Stm32_Target2[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target2[0] == 17 && Stm32_Target2[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target2[0] == 19 && Stm32_Target2[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target2[0] == 19 && Stm32_Target2[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target2[0] == 15 && Stm32_Target2[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target2[0] == 19 && Stm32_Target2[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target2[0] == 15 && Stm32_Target2[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target2[0] == 17 && Stm32_Target2[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target2[0] == 11 && Stm32_Target2[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target2[0] == 11 && Stm32_Target2[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target2[0] == 13 && Stm32_Target2[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target2[0] == 13 && Stm32_Target2[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target2[0] == 7 && Stm32_Target2[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target2[0] == 9 && Stm32_Target2[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target2[0] == 9 && Stm32_Target2[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target2[0] == 1 && Stm32_Target2[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target2[0] == 5 && Stm32_Target2[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target2[0] == 3 && Stm32_Target2[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target2[0] == 3 && Stm32_Target2[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target2[0] == 5 && Stm32_Target2[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target2[0] == 1 && Stm32_Target2[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target2[0] == 1 && Stm32_Target2[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target2[0] == 5 && Stm32_Target2[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target2[0] == 7 && Stm32_Target2[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}


		if(i==2)
		{
			if(Stm32_Target3[0] == 15 && Stm32_Target3[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target3[0] == 17 && Stm32_Target3[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target3[0] == 19 && Stm32_Target3[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target3[0] == 19 && Stm32_Target3[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target3[0] == 15 && Stm32_Target3[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target3[0] == 19 && Stm32_Target3[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target3[0] == 15 && Stm32_Target3[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target3[0] == 17 && Stm32_Target3[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target3[0] == 11 && Stm32_Target3[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target3[0] == 11 && Stm32_Target3[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target3[0] == 13 && Stm32_Target3[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target3[0] == 13 && Stm32_Target3[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target3[0] == 7 && Stm32_Target3[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target3[0] == 9 && Stm32_Target3[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target3[0] == 9 && Stm32_Target3[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target3[0] == 1 && Stm32_Target3[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target3[0] == 5 && Stm32_Target3[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target3[0] == 3 && Stm32_Target3[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target3[0] == 3 && Stm32_Target3[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target3[0] == 5 && Stm32_Target3[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target3[0] == 1 && Stm32_Target3[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target3[0] == 1 && Stm32_Target3[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target3[0] == 5 && Stm32_Target3[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target3[0] == 7 && Stm32_Target3[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}


		if(i==3)
		{
			if(Stm32_Target4[0] == 15 && Stm32_Target4[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target4[0] == 17 && Stm32_Target4[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target4[0] == 19 && Stm32_Target4[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target4[0] == 19 && Stm32_Target4[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target4[0] == 15 && Stm32_Target4[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target4[0] == 19 && Stm32_Target4[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target4[0] == 15 && Stm32_Target4[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target4[0] == 17 && Stm32_Target4[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target4[0] == 11 && Stm32_Target4[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target4[0] == 11 && Stm32_Target4[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target4[0] == 13 && Stm32_Target4[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target4[0] == 13 && Stm32_Target4[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target4[0] == 7 && Stm32_Target4[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target4[0] == 9 && Stm32_Target4[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target4[0] == 9 && Stm32_Target4[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target4[0] == 1 && Stm32_Target4[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target4[0] == 5 && Stm32_Target4[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target4[0] == 3 && Stm32_Target4[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target4[0] == 3 && Stm32_Target4[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target4[0] == 5 && Stm32_Target4[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target4[0] == 1 && Stm32_Target4[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target4[0] == 1 && Stm32_Target4[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target4[0] == 5 && Stm32_Target4[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target4[0] == 7 && Stm32_Target4[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}


		
		if(i==4)
		{
			if(Stm32_Target5[0] == 15 && Stm32_Target5[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target5[0] == 17 && Stm32_Target5[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target5[0] == 19 && Stm32_Target5[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target5[0] == 19 && Stm32_Target5[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target5[0] == 15 && Stm32_Target5[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target5[0] == 19 && Stm32_Target5[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target5[0] == 15 && Stm32_Target5[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target5[0] == 17 && Stm32_Target5[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target5[0] == 11 && Stm32_Target5[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target5[0] == 11 && Stm32_Target5[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target5[0] == 13 && Stm32_Target5[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target5[0] == 13 && Stm32_Target5[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target5[0] == 7 && Stm32_Target5[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target5[0] == 9 && Stm32_Target5[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target5[0] == 9 && Stm32_Target5[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target5[0] == 1 && Stm32_Target5[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target5[0] == 5 && Stm32_Target5[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target5[0] == 3 && Stm32_Target5[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target5[0] == 3 && Stm32_Target5[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target5[0] == 5 && Stm32_Target5[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target5[0] == 1 && Stm32_Target5[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target5[0] == 1 && Stm32_Target5[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target5[0] == 5 && Stm32_Target5[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target5[0] == 7 && Stm32_Target5[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}
		if(i==5)
		{
			if(Stm32_Target6[0] == 15 && Stm32_Target6[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target6[0] == 17 && Stm32_Target6[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target6[0] == 19 && Stm32_Target6[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target6[0] == 19 && Stm32_Target6[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target6[0] == 15 && Stm32_Target6[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target6[0] == 19 && Stm32_Target6[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target6[0] == 15 && Stm32_Target6[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target6[0] == 17 && Stm32_Target6[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target6[0] == 11 && Stm32_Target6[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target6[0] == 11 && Stm32_Target6[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target6[0] == 13 && Stm32_Target6[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target6[0] == 13 && Stm32_Target6[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target6[0] == 7 && Stm32_Target6[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target6[0] == 9 && Stm32_Target6[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target6[0] == 9 && Stm32_Target6[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target6[0] == 1 && Stm32_Target6[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target6[0] == 5 && Stm32_Target6[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target6[0] == 3 && Stm32_Target6[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target6[0] == 3 && Stm32_Target6[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target6[0] == 5 && Stm32_Target6[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target6[0] == 1 && Stm32_Target6[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target6[0] == 1 && Stm32_Target6[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target6[0] == 5 && Stm32_Target6[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target6[0] == 7 && Stm32_Target6[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}

          if(i==6)
		{
			if(Stm32_Target7[0] == 15 && Stm32_Target7[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target7[0] == 17 && Stm32_Target7[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target7[0] == 19 && Stm32_Target7[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target7[0] == 19 && Stm32_Target7[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target7[0] == 15 && Stm32_Target7[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target7[0] == 19 && Stm32_Target7[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target7[0] == 15 && Stm32_Target7[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target7[0] == 17 && Stm32_Target7[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target7[0] == 11 && Stm32_Target7[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target7[0] == 11 && Stm32_Target7[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target7[0] == 13 && Stm32_Target7[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target7[0] == 13 && Stm32_Target7[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target7[0] == 7 && Stm32_Target7[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target7[0] == 9 && Stm32_Target7[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target7[0] == 9 && Stm32_Target7[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target7[0] == 1 && Stm32_Target7[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target7[0] == 5 && Stm32_Target7[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target7[0] == 3 && Stm32_Target7[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target7[0] == 3 && Stm32_Target7[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target7[0] == 5 && Stm32_Target7[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target7[0] == 1 && Stm32_Target7[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target7[0] == 1 && Stm32_Target7[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target7[0] == 5 && Stm32_Target7[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target7[0] == 7 && Stm32_Target7[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}
		if(i==7)
		{
			if(Stm32_Target8[0] == 15 && Stm32_Target8[1] == 11)
			{
				Stm32_Target1_Arrange[0] = 15;
				Stm32_Target1_Arrange[1] = 11;
			}
			else if(Stm32_Target8[0] == 17 && Stm32_Target8[1] == 7)
			{
				Stm32_Target2_Arrange[0] = 17;
				Stm32_Target2_Arrange[1] = 7;
			}
			else if(Stm32_Target8[0] == 19 && Stm32_Target8[1] == 9)
			{
				Stm32_Target3_Arrange[0] = 19;
				Stm32_Target3_Arrange[1] = 9;
			}
			else if(Stm32_Target8[0] == 19 && Stm32_Target8[1] == 5)
			{
				Stm32_Target4_Arrange[0] = 19;
				Stm32_Target4_Arrange[1] = 5;
			}
			else if(Stm32_Target8[0] == 15 && Stm32_Target8[1] == 5)
			{
				Stm32_Target5_Arrange[0] = 15;
				Stm32_Target5_Arrange[1] = 5;
			}
			else if(Stm32_Target8[0] == 19 && Stm32_Target8[1] == 19)
			{
				Stm32_Target6_Arrange[0] = 19;
				Stm32_Target6_Arrange[1] = 19;
			}
			else if(Stm32_Target8[0] == 15 && Stm32_Target8[1] == 19)
			{
				Stm32_Target7_Arrange[0] = 15;
				Stm32_Target7_Arrange[1] = 19;
			}
			else if(Stm32_Target8[0] == 17 && Stm32_Target8[1] == 17)
			{
				Stm32_Target8_Arrange[0] = 17;
				Stm32_Target8_Arrange[1] = 17;
			}
			else if(Stm32_Target8[0] == 11 && Stm32_Target8[1] == 15)
			{
				Stm32_Target9_Arrange[0] = 11;
				Stm32_Target9_Arrange[1] = 15;
			}
			else if(Stm32_Target8[0] == 11 && Stm32_Target8[1] == 17)
			{
				Stm32_Target10_Arrange[0] = 11;
				Stm32_Target10_Arrange[1] = 17;
			}
			else if(Stm32_Target8[0] == 13 && Stm32_Target8[1] == 9)
			{
				Stm32_Target11_Arrange[0] = 13;
				Stm32_Target11_Arrange[1] = 9;
			}
			else if(Stm32_Target8[0] == 13 && Stm32_Target8[1] == 1)
			{
				Stm32_Target12_Arrange[0] = 13;
				Stm32_Target12_Arrange[1] = 1;
			}
			else if(Stm32_Target8[0] == 7 && Stm32_Target8[1] == 11)
			{
				Stm32_Target13_Arrange[0] = 7;
				Stm32_Target13_Arrange[1] = 11;
			}
			else if(Stm32_Target8[0] == 9 && Stm32_Target8[1] == 5)
			{
				Stm32_Target14_Arrange[0] = 9;
				Stm32_Target14_Arrange[1] = 5;
			}
			else if(Stm32_Target8[0] == 9 && Stm32_Target8[1] == 3)
			{
				Stm32_Target15_Arrange[0] = 9;
				Stm32_Target15_Arrange[1] = 3;
			}
			else if(Stm32_Target8[0] == 1 && Stm32_Target8[1] == 1)
			{
				Stm32_Target16_Arrange[0] = 1;
				Stm32_Target16_Arrange[1] = 1;
			}
			else if(Stm32_Target8[0] == 5 && Stm32_Target8[1] == 1)
			{
				Stm32_Target17_Arrange[0] = 5;
				Stm32_Target17_Arrange[1] = 1;
			}
			else if(Stm32_Target8[0] == 3 && Stm32_Target8[1] == 3)
			{
				Stm32_Target18_Arrange[0] = 3;
				Stm32_Target18_Arrange[1] = 3;
			}
			else if(Stm32_Target8[0] == 3 && Stm32_Target8[1] == 13)
			{
				Stm32_Target19_Arrange[0] = 3;
				Stm32_Target19_Arrange[1] = 13;
			}
			else if(Stm32_Target8[0] == 5 && Stm32_Target8[1] == 9)
			{
				Stm32_Target20_Arrange[0] = 5;
				Stm32_Target20_Arrange[1] = 9;
			}
			else if(Stm32_Target8[0] == 1 && Stm32_Target8[1] == 11)
			{
				Stm32_Target21_Arrange[0] = 1;
				Stm32_Target21_Arrange[1] = 11;
			}
			else if(Stm32_Target8[0] == 1 && Stm32_Target8[1] == 15)
			{
				Stm32_Target22_Arrange[0] = 1;
				Stm32_Target22_Arrange[1] = 15;
			}
			else if(Stm32_Target8[0] == 5 && Stm32_Target8[1] == 15)
			{
				Stm32_Target23_Arrange[0] = 5;
				Stm32_Target23_Arrange[1] = 15;
			}
			else if(Stm32_Target8[0] == 7 && Stm32_Target8[1] == 19)
			{
				Stm32_Target24_Arrange[0] = 7;
				Stm32_Target24_Arrange[1] = 19;
			}
		}
	}

	  Stm32_Target_Arrange_temp[0] = Stm32_Target1_Arrange[0];
	  Stm32_Target_Arrange_temp[1] = Stm32_Target1_Arrange[1];
	  Stm32_Target_Arrange_temp[2] = Stm32_Target2_Arrange[0];
	  Stm32_Target_Arrange_temp[3] = Stm32_Target2_Arrange[1];
	  Stm32_Target_Arrange_temp[4] = Stm32_Target3_Arrange[0];
	  Stm32_Target_Arrange_temp[5] = Stm32_Target3_Arrange[1];
	  Stm32_Target_Arrange_temp[6] = Stm32_Target4_Arrange[0];
	  Stm32_Target_Arrange_temp[7] = Stm32_Target4_Arrange[1];
	  Stm32_Target_Arrange_temp[8] = Stm32_Target5_Arrange[0];
	  Stm32_Target_Arrange_temp[9] = Stm32_Target5_Arrange[1];
	  Stm32_Target_Arrange_temp[10] = Stm32_Target6_Arrange[0];
	  Stm32_Target_Arrange_temp[11] = Stm32_Target6_Arrange[1];
	  Stm32_Target_Arrange_temp[12] = Stm32_Target7_Arrange[0];
	  Stm32_Target_Arrange_temp[13] = Stm32_Target7_Arrange[1];
	  Stm32_Target_Arrange_temp[14] = Stm32_Target8_Arrange[0];
	  Stm32_Target_Arrange_temp[15] = Stm32_Target8_Arrange[1];
	  Stm32_Target_Arrange_temp[16] = Stm32_Target9_Arrange[0];
	  Stm32_Target_Arrange_temp[17] = Stm32_Target9_Arrange[1];
	  Stm32_Target_Arrange_temp[18] = Stm32_Target10_Arrange[0];
	  Stm32_Target_Arrange_temp[19] = Stm32_Target10_Arrange[1];
	  Stm32_Target_Arrange_temp[20] = Stm32_Target11_Arrange[0];
	  Stm32_Target_Arrange_temp[21] = Stm32_Target11_Arrange[1];
	  Stm32_Target_Arrange_temp[22] = Stm32_Target12_Arrange[0];
	  Stm32_Target_Arrange_temp[23] = Stm32_Target12_Arrange[1];
	  Stm32_Target_Arrange_temp[24] = Stm32_Target13_Arrange[0];
	  Stm32_Target_Arrange_temp[25] = Stm32_Target13_Arrange[1];
	  Stm32_Target_Arrange_temp[26] = Stm32_Target14_Arrange[0];
	  Stm32_Target_Arrange_temp[27] = Stm32_Target14_Arrange[1];
	  Stm32_Target_Arrange_temp[28] = Stm32_Target15_Arrange[0];
	  Stm32_Target_Arrange_temp[29] = Stm32_Target15_Arrange[1];
	  Stm32_Target_Arrange_temp[30] = Stm32_Target16_Arrange[0];
	  Stm32_Target_Arrange_temp[31] = Stm32_Target16_Arrange[1];
	  Stm32_Target_Arrange_temp[32] = Stm32_Target17_Arrange[0];
	  Stm32_Target_Arrange_temp[33] = Stm32_Target17_Arrange[1];
	  Stm32_Target_Arrange_temp[34] = Stm32_Target18_Arrange[0];
	  Stm32_Target_Arrange_temp[35] = Stm32_Target18_Arrange[1];
	  Stm32_Target_Arrange_temp[36] = Stm32_Target19_Arrange[0];
	  Stm32_Target_Arrange_temp[37] = Stm32_Target19_Arrange[1];
	  Stm32_Target_Arrange_temp[38] = Stm32_Target20_Arrange[0];
	  Stm32_Target_Arrange_temp[39] = Stm32_Target20_Arrange[1];
	  Stm32_Target_Arrange_temp[40] = Stm32_Target21_Arrange[0];
	  Stm32_Target_Arrange_temp[41] = Stm32_Target21_Arrange[1];
	  Stm32_Target_Arrange_temp[42] = Stm32_Target22_Arrange[0];
	  Stm32_Target_Arrange_temp[43] = Stm32_Target22_Arrange[1];
	  Stm32_Target_Arrange_temp[44] = Stm32_Target23_Arrange[0];
	  Stm32_Target_Arrange_temp[45] = Stm32_Target23_Arrange[1];
	  Stm32_Target_Arrange_temp[46] = Stm32_Target24_Arrange[0];
	  Stm32_Target_Arrange_temp[47] = Stm32_Target24_Arrange[1];
	  for(i=0,j=0;i<48;i++)
	  {
		  if( Stm32_Target_Arrange_temp[i] != 0)
		  {
			  Stm32_Target_Arrange_temp_output[j++]= Stm32_Target_Arrange_temp[i];
		  }
	  }
	  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output[0];
	  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output[1];
	  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output[2];
	  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output[3];
	  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output[4];
	  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output[5];
	  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output[6];
	  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output[7];
	  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output[8];
	  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output[9];
	  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output[10];
	  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output[11];
	  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output[12];
	  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output[13];
	  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output[14];
	  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output[15];


}
void Go_through_all_the_points(void)
{
	if(Stm32_Target1_Arrange[0] == 15 && Stm32_Target1_Arrange[1] == 11)
	{
		map[16][11] = 1;
		map[5][1] = 1;
		map_original[16][11] = 1;
		map_original[5][11] = 1;
		BFS_map_original[16][11] = 1;
		BFS_map_original[5][11] = 1;
	}
	if(Stm32_Target2_Arrange[0] == 17 && Stm32_Target2_Arrange[1] == 7)
	{
		map[17][8] = 1;
		map[3][12] = 1;
		map_original[17][8] = 1;
		map_original[3][12] = 1;
		BFS_map_original[17][8] = 1;
		BFS_map_original[3][12] = 1;
	}
}
void Total_path_planning_break(int destination[2],int map[21][21])
{
	    int i;
		if(destination[0] == 0 && destination[1] == 0)
	   {
		   destination[0] = 1;
		   destination[1] = 19;
	   }
	   if(destination[0] == 1 && destination[1] == 19)
	   {
		   ending = 1;
	   }
		BFS(map,19,1,destination[0],destination[1]);
		Judge_node(BFS_map_original,19,1,destination[0],destination[1]);
		for (i = 0; i < 30; i++)
		{
			Turn_temp_break[i]=Turn_temp[i];
		}
}
void Total_path_planning_myself_ultimate(int Target[2],int destination[2],int map[21][21],int sequence)
{
	    int i;
		if(destination[0] == 13 && destination[1] == 1)
	   {
		   map[19][12]= 1;
	   }
		if(destination[0] == 7 && destination[1] == 19)
	   {
		   map[1][8]= 1;
	   }
		if(destination[0] == 0 && destination[1] == 0)
	   {
		   destination[0] = 1;
		   destination[1] = 19;
	   }
	   if(destination[0] == 1 && destination[1] == 19)
	   {
		   ending = 1;
	   }
		BFS(map,Target[0],Target[1],destination[0],destination[1]);
		Judge_node(BFS_map_original,Target[0],Target[1],destination[0],destination[1]);

	   switch(sequence)
		{ 
			case 1:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp1[i]=Turn_temp[i];
				}
				break;
			}
			case 2:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp2[i]=Turn_temp[i];
				}
				break;
			}
			case 3:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp3[i]=Turn_temp[i];
				}
				break;
			}
			case 4:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp4[i]=Turn_temp[i];
				}
				break;
			}
			case 5:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp5[i]=Turn_temp[i];
				}
				break;
			}
			case 6:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp6[i]=Turn_temp[i];
				}
				break;
			}
			case 7:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp7[i]=Turn_temp[i];
				}
				break;
			}
			case 8:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp8[i]=Turn_temp[i];
				}
				break;
			}
			case 9:
			{
				for (i = 0; i < 30; i++)
				{
				   Turn_temp9[i]=Turn_temp[i];
				}
				break;
			}
		 }
}
void Path_planning_update()
{
	 int i,j=0;
	 //�����������0
		 for (i = 0; i < 20; i++)
        {
              Turn_temp[i]= 0;
        }
		 //�������ͼ�������Ϊ��ʼ��ͼ����
		 for (i = 0; i < 21; i++)
        {
            for (j = 0; j < 21; j++)
            {
			  map[i][j]= map_original[i][j];
            }
        }
		 //�������ͼ�������Ϊ��ʼ��ͼ����
		 for (i = 0; i < 21; i++)
        {
            for (j = 0; j < 21; j++)
            {
			  BFS_map_original[i][j]= map_original[i][j];
            }
        }
}
void Delete_point_Path_planning(int sequence,int now_condition,int Own_color)
{
	/*now_conditionΪ��ǰ���ص������
	  1.����
	  2.���
	  3.����
	  4.����
	*/
	/*first_conditionΪ��һ�ֱ��ص������
	  1.����
	  2.���
	  3.����
	  4.����
	*/
	//�жϼ���Ϊ��ɫ���ߺ�ɫ
	//0�Ǻ�ɫ��1����ɫ
	switch(Own_color)
	{
	   case 1:
	   if((0<sequence)&&(sequence<10))
		{
			switch(sequence)
			{
				case 1:
				Total_path_planning_myself_ultimate(Begin_point,Stm32_Target1,map,1);
			    Path_planning_update();
				return;
				case 2:
				first_condition = now_condition;
				 if(first_condition == 1)
				{
					Delete_quadrant_point_arrangement_first_point(1,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					red_true_num++;
					return;
				}
				 else if(first_condition == 2)
				{
					Delete_quadrant_point_arrangement_first_point(1,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					red_false_num++;
					return;
				}
				else if(first_condition == 3)
				{
					Delete_quadrant_point_arrangement_first_point(2,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					blue_true_num++;
					return;
				}
				else if(first_condition == 4)
				{
					Delete_quadrant_point_arrangement_first_point(3,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					blue_false_num++;
					return;
				}
				case 3:
				 second_condition = now_condition;
				 if(((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)) )
				{
					switch(first_condition)
					{
						//��һ������Ϊ����
					   case 3:
						{
							switch(second_condition)
							{
								case 1:
								Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
								Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					            Path_planning_update();
								red_true_num++;
								return;
								case 2:
								Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
								Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					            Path_planning_update();
								red_false_num++;
								return;
							}
						}
						case 4:
						{
							//��һ������Ϊ��α
							Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
							Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					        Path_planning_update();
							red_true_num++;
							return;
						}
					}
				 }
				 if((((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((0<Stm32_Target1[1])&&(Stm32_Target1[1]<10)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)))||(((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((0<Stm32_Target2[1])&&(Stm32_Target2[1]<10))) )
				 {
					 if(second_condition == 1)
				{
					Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					red_true_num++;
					return;
				}
				 else if(second_condition == 2)
				{
					Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					red_false_num++;
					return;
				}
				else if(second_condition == 3)
				{
					Delete_quadrant_point_arrangement_second_point(2,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					blue_true_num++;
					return;
				}
				else if(second_condition == 4)
				{
					Delete_quadrant_point_arrangement_second_point(3,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					blue_false_num++;
					return;
				}
				 }
				case 4:
				{
					 third_condition = now_condition;
					 if(((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)) )
					 {
					    if(third_condition == 1)
						{
							Delete_quadrant_point_arrangement_third_point(1,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_true_num++;
							return;
						}
						 else if(third_condition == 2)
						{
							Delete_quadrant_point_arrangement_third_point(1,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_false_num++;
							return;
						}
						else if(third_condition == 3)
						{
							Delete_quadrant_point_arrangement_third_point(2,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_true_num++;
							return;
						}
						else if(third_condition == 4)
						{
							Delete_quadrant_point_arrangement_third_point(3,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_false_num++;
							return;
						}
					 }
					 else  if(((10<Stm32_Target3[0])&&(Stm32_Target3[0]<20))&&((0<Stm32_Target3[1])&&(Stm32_Target3[1]<10)) && ((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20))&&((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((0<Stm32_Target2[1])&&(Stm32_Target2[1]<10)) )
					 {
						 switch(third_condition)
						 {
							case 1:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_true_num++;
							return;
							case 2:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_false_num++;
							return;
						 }
					 }
					 else if(((10<Stm32_Target3[0])&&(Stm32_Target3[0]<20))&&((10<Stm32_Target3[1])&&(Stm32_Target3[1]<20)) && ((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((0<Stm32_Target1[1])&&(Stm32_Target1[1]<10))&&((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((0<Stm32_Target2[1])&&(Stm32_Target2[1]<10)) )
					 {
						 switch(third_condition)
						 {
							case 1:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_true_num++;
							return;
							case 2:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_false_num++;
							return;
						 }
					 }
					 else if(((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)) && ((10<Stm32_Target3[0])&&(Stm32_Target3[0]<20))&&((10<Stm32_Target3[1])&&(Stm32_Target3[1]<20)) )
					 {
						    switch(second_condition)
							{
								//�ڶ�������Ϊ����
								case 3:
								{
									switch(third_condition)
									{
										case 1:
										Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
										Path_planning_update();
										red_true_num++;
										return;
										case 2:
										Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
										Path_planning_update();
										red_false_num++;
										return;
									}
								}
								case 4:
								{
									//�ڶ�������Ϊ��α
									Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
									Path_planning_update();
									red_true_num++;
									return;
								}
							}
					 }
					 else
					 {
						 switch(third_condition)
						 {
						     case 1:
							 if(red_true_num == 2)
							 {
								 Total_path_planning_myself_ultimate(Stm32_Target3,Eeding_point,map,4);
							     Path_planning_update();
							 }
							 else 
							 {
								 Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							     Path_planning_update();
								 red_true_num++;
							 }
							 return;
							 case 2:
							 Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							 Path_planning_update();
							 return;
						 }
					 }
				}
				case 5:
				{
					if(now_condition == 1 && red_true_num == 2)
					{
						Total_path_planning_myself_ultimate(Stm32_Target4,Eeding_point,map,5);
						Path_planning_update();
						return;
					}
					else 
					{
						 Total_path_planning_myself_ultimate(Stm32_Target4,Stm32_Target5,map,5);
						 Path_planning_update();
						 if(now_condition == 1)
						 red_true_num++;
						 return;
					}
				}
				case 6:
				{
					if(now_condition == 1 && red_true_num == 2)
					{
						Total_path_planning_myself_ultimate(Stm32_Target5,Eeding_point,map,6);
						Path_planning_update();
						return;
					}
					else
					{
						 Total_path_planning_myself_ultimate(Stm32_Target5,Stm32_Target6,map,6);
						 Path_planning_update();
						 if(now_condition == 1)
						 red_true_num++;
						 return;
					}
				}
				case 7:
				{
					if(now_condition == 1 && red_true_num == 2)
					{
						Total_path_planning_myself_ultimate(Stm32_Target6,Eeding_point,map,7);
						Path_planning_update();
						return;
					}
					else
					{
						 Total_path_planning_myself_ultimate(Stm32_Target6,Eeding_point,map,7);
						 Path_planning_update();
						 return;
					}
				}
			}
		}
	   //����Ϊ����
	   case 2:
	   if((0<sequence)&&(sequence<10))
		{
			switch(sequence)
			{
				case 1:
				Total_path_planning_myself_ultimate(Begin_point,Stm32_Target1,map,1);
			    Path_planning_update();
				return;
				case 2:
				first_condition = now_condition;
				 if(first_condition == 3)
				{
					Delete_quadrant_point_arrangement_first_point(1,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					blue_true_num++;
					return;
				}
				 else if(first_condition == 4)
				{
					Delete_quadrant_point_arrangement_first_point(1,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					blue_false_num++;
					return;
				}
				else if(first_condition == 1)
				{
					Delete_quadrant_point_arrangement_first_point(2,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					red_true_num++;
					return;
				}
				else if(first_condition == 2)
				{
					Delete_quadrant_point_arrangement_first_point(3,Stm32_Target1);
					Total_path_planning_myself_ultimate(Stm32_Target1,Stm32_Target2,map,2);
					Path_planning_update();
					red_false_num++;
					return;
				}
				case 3:
				 second_condition = now_condition;
				 if(((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)) )
				{
					switch(first_condition)
					{
						//��һ������Ϊ����
					   case 1:
						{
							switch(second_condition)
							{
								case 3:
								Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
								Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					            Path_planning_update();
								blue_true_num++;
								return;
								case 4:
								Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
								Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					            Path_planning_update();
								blue_false_num++;
								return;
							}
						}
						case 2:
						{
							//��һ������Ϊ��α
							Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
							Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					        Path_planning_update();
							blue_true_num++;
							return;
						}
					}
				 }
				 if((((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((0<Stm32_Target1[1])&&(Stm32_Target1[1]<10)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)))||(((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((0<Stm32_Target2[1])&&(Stm32_Target2[1]<10))) )
				 {
					 if(second_condition == 3)
				{
					Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					blue_true_num++;
					return;
				}
				 else if(second_condition == 4)
				{
					Delete_quadrant_point_arrangement_second_point(1,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					blue_false_num++;
					return;
				}
				else if(second_condition == 1)
				{
					Delete_quadrant_point_arrangement_second_point(2,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					red_true_num++;
					return;
				}
				else if(second_condition == 2)
				{
					Delete_quadrant_point_arrangement_second_point(3,Stm32_Target2);
					Total_path_planning_myself_ultimate(Stm32_Target2,Stm32_Target3,map,3);
					Path_planning_update();
					red_false_num++;
					return;
				}
				 }
				case 4:
				{
					 third_condition = now_condition;
					 if(((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20)) && ((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)) )
					 {
					    if(third_condition == 3)
						{	

							Delete_quadrant_point_arrangement_third_point(1,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_true_num++;
							return;
						}
						 else if(third_condition == 4)
						{
							Delete_quadrant_point_arrangement_third_point(1,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_false_num++;
							return;
						}
						else if(third_condition == 1)
						{
							Delete_quadrant_point_arrangement_third_point(2,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_true_num++;
							return;
						}
						else if(third_condition == 2)
						{
							Delete_quadrant_point_arrangement_third_point(3,Stm32_Target3);
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							red_false_num++;
							return;
						}
					 }
					 else  if(((10<Stm32_Target3[0])&&(Stm32_Target3[0]<20))&&((0<Stm32_Target3[1])&&(Stm32_Target3[1]<10)) && ((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((10<Stm32_Target1[1])&&(Stm32_Target1[1]<20))&&((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((0<Stm32_Target2[1])&&(Stm32_Target2[1]<10)) )
					 {
						 switch(third_condition)
						 {
							case 3:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_true_num++;
							return;
							case 4:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_false_num++;
							return;
						 }
					 }
					 else if(((10<Stm32_Target3[0])&&(Stm32_Target3[0]<20))&&((10<Stm32_Target3[1])&&(Stm32_Target3[1]<20)) && ((10<Stm32_Target1[0])&&(Stm32_Target1[0]<20))&&((0<Stm32_Target1[1])&&(Stm32_Target1[1]<10))&&((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)) )
					 {
						 switch(third_condition)
						 {
							case 3:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_true_num++;
							return;
							case 4:
							Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							Path_planning_update();
							blue_false_num++;
							return;
						 }
					 }
					 else if(((10<Stm32_Target2[0])&&(Stm32_Target2[0]<20))&&((10<Stm32_Target2[1])&&(Stm32_Target2[1]<20)) && ((10<Stm32_Target3[0])&&(Stm32_Target3[0]<20))&&((10<Stm32_Target3[1])&&(Stm32_Target3[1]<20)) )
					 {
						    switch(second_condition)
							{
								//�ڶ�������Ϊ����
								case 1:
								{
									switch(third_condition)
									{
										case 3:
										Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
										Path_planning_update();
										blue_true_num++;
										return;
										case 4:
										Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
										Path_planning_update();
										blue_false_num++;
										return;
									}
								}
								case 2:
								{
									//�ڶ�������Ϊ��α
									Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
									Path_planning_update();
									blue_true_num++;
									return;
								}
							}
					 }
					 else
					 {
						 switch(third_condition)
						 {
						     case 3:
							 if(blue_true_num == 2)
							 {
								  Total_path_planning_myself_ultimate(Stm32_Target3,Eeding_point,map,4);
							      Path_planning_update();
							 }
							 else
							 {
								 Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							     Path_planning_update();
								 blue_true_num++;
							 }
							 return;
							 case 4:
							 Total_path_planning_myself_ultimate(Stm32_Target3,Stm32_Target4,map,4);
							 Path_planning_update();
							 blue_false_num++;
							 return;
						 }
					 }
				}
				case 5:
				{
					if(now_condition == 3 && blue_true_num == 2)
					{
						Total_path_planning_myself_ultimate(Stm32_Target4,Eeding_point,map,5);
						Path_planning_update();
						return;
					}
					else
					{
						 Total_path_planning_myself_ultimate(Stm32_Target4,Stm32_Target5,map,5);
						 Path_planning_update();
						 if(now_condition == 3)
						 blue_true_num++;
						 return;
					}
				}
				case 6:
				{
					if(now_condition == 3 && blue_true_num == 2)
					{
						Total_path_planning_myself_ultimate(Stm32_Target5,Eeding_point,map,6);
						Path_planning_update();
						return;
					}
					else
					{
						 Total_path_planning_myself_ultimate(Stm32_Target5,Stm32_Target6,map,6);
						 Path_planning_update();
						 if(now_condition == 3)
						 blue_true_num++;
						 return;
					}
				}
				case 7:
				{
					if(now_condition == 3 && blue_true_num == 2)
					{
						Total_path_planning_myself_ultimate(Stm32_Target6,Eeding_point,map,7);
						Path_planning_update();
						return;
					}
					else
					{
						 Total_path_planning_myself_ultimate(Stm32_Target6,Eeding_point,map,7);
						 Path_planning_update();
						 return;
					}
				}
			}
		}
	}
}
void Delete_quadrant_point_arrangement_first_point(int metrue, int Target[2])
{
	//meture��1Ϊ����򼺼٣�2Ϊ����,3Ϊ�м�
	int i,j;
	int quadrant;
	switch(metrue)
	{
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 1:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				
				//��һ����
			   case 1:
				   for(i=2;i<16;i=i+2)
				 {
					if((( Stm32_Target_Arrange_temp_output[i] == (20 - Target[0])) && (Stm32_Target_Arrange_temp_output[i+1] == (20 - Target[1])))||(((10<Stm32_Target_Arrange_temp_output[i])&&(Stm32_Target_Arrange_temp_output[i]<20)) && ((0<Stm32_Target_Arrange_temp_output[i+1])&&(Stm32_Target_Arrange_temp_output[i+1]<10))))
					{
						Stm32_Target_Arrange_temp_output[i]=0;
						Stm32_Target_Arrange_temp_output[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point[j++]= Stm32_Target_Arrange_temp_output[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point[13];
					  Stm32_Target8[0] = 0;
					  Stm32_Target8[1] = 0;
				break;
				case 2:
				   for(i=2;i<16;i=i+2)
				 {
					if((( Stm32_Target_Arrange_temp_output[i] == (20 - Target[0])) && (Stm32_Target_Arrange_temp_output[i+1] == (20 - Target[1])))||(((10<Stm32_Target_Arrange_temp_output[i])&&(Stm32_Target_Arrange_temp_output[i]<20)) && ((10<Stm32_Target_Arrange_temp_output[i+1])&&(Stm32_Target_Arrange_temp_output[i+1]<20))))
					{
						Stm32_Target_Arrange_temp_output[i]=0;
						Stm32_Target_Arrange_temp_output[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point[j++]= Stm32_Target_Arrange_temp_output[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point[13];
					  Stm32_Target8[0] = 0;
					  Stm32_Target8[1] = 0;
				 break;
			}
			break;
		}
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 2:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				//��һ����
			   case 1:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output[i])&&(Stm32_Target_Arrange_temp_output[i]<10)) && ((10<Stm32_Target_Arrange_temp_output[i+1])&&(Stm32_Target_Arrange_temp_output[i+1]<20)))
					{
						if(( Stm32_Target_Arrange_temp_output[i] != (20 - Target[0])) || (Stm32_Target_Arrange_temp_output[i+1] != (20 - Target[1])))
						{
							Stm32_Target_Arrange_temp_output[i]=0;
							Stm32_Target_Arrange_temp_output[i+1]=0;
						}
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point[j++]= Stm32_Target_Arrange_temp_output[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point[13];
					  Stm32_Target8[0] = 0;
					  Stm32_Target8[1] = 0;
				break;
				case 2:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output[i])&&(Stm32_Target_Arrange_temp_output[i]<10)) && ((0<Stm32_Target_Arrange_temp_output[i+1])&&(Stm32_Target_Arrange_temp_output[i+1]<10)))
					{
						if(( Stm32_Target_Arrange_temp_output[i] != (20 - Target[0])) || (Stm32_Target_Arrange_temp_output[i+1] != (20 - Target[1])))
						{
							Stm32_Target_Arrange_temp_output[i]=0;
						    Stm32_Target_Arrange_temp_output[i+1]=0;
						}
					}
				  }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point[j++]= Stm32_Target_Arrange_temp_output[i];
					}
				}
					  
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point[13];
					  Stm32_Target8[0] = 0;
					  Stm32_Target8[1] = 0;
				 break;
			}
		break;
		}
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 3:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				//��һ����
			   case 1:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output[i])&&(Stm32_Target_Arrange_temp_output[i]<10)) && ((10<Stm32_Target_Arrange_temp_output[i+1])&&(Stm32_Target_Arrange_temp_output[i+1]<20)))
					{
						Stm32_Target_Arrange_temp_output[i]=0;
						Stm32_Target_Arrange_temp_output[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point[j++]= Stm32_Target_Arrange_temp_output[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point[11];
					  Stm32_Target7[0] = 0;
					  Stm32_Target7[1] = 0;
					  Stm32_Target8[0] = 0;
					  Stm32_Target8[1] = 0;
				break;
				case 2:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output[i])&&(Stm32_Target_Arrange_temp_output[i]<10)) && ((0<Stm32_Target_Arrange_temp_output[i+1])&&(Stm32_Target_Arrange_temp_output[i+1]<10)))
					{
						Stm32_Target_Arrange_temp_output[i]=0;
						Stm32_Target_Arrange_temp_output[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point[j++]= Stm32_Target_Arrange_temp_output[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point[11];
					  Stm32_Target7[0] = 0;
					  Stm32_Target7[1] = 0;
					  Stm32_Target8[0] = 0;
					  Stm32_Target8[1] = 0;
					  break;
			}
		  break;
	  }
   }
}
void Delete_quadrant_point_arrangement_second_point(int metrue, int Target[2])
{
	//meture��1Ϊ����򼺼٣�2Ϊ����,3Ϊ�м�
	int i,j;
	int quadrant;
	switch(metrue)
	{
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 1:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				
				//��һ����
			   case 1:
				   for(i=4;i<16;i=i+2)
				 {
					if(( (Stm32_Target_Arrange_temp_output_delet_point[i] == (20 - Target[0])) && (Stm32_Target_Arrange_temp_output_delet_point[i+1] == (20 - Target[1])))||(((10<Stm32_Target_Arrange_temp_output_delet_point[i])&&(Stm32_Target_Arrange_temp_output_delet_point[i]<20)) && ((0<Stm32_Target_Arrange_temp_output_delet_point[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point[i+1]<10))))
					{
						Stm32_Target_Arrange_temp_output_delet_point[i]=0;
						Stm32_Target_Arrange_temp_output_delet_point[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point2[j++]= Stm32_Target_Arrange_temp_output_delet_point[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point2[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point2[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point2[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point2[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point2[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point2[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point2[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point2[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point2[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point2[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point2[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point2[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point2[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point2[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point2[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point2[15];
				break;
				case 2:
				   for(i=4;i<16;i=i+2)
				 {
					if(((Stm32_Target_Arrange_temp_output_delet_point[i] == (20 - Target[0])) && (Stm32_Target_Arrange_temp_output_delet_point[i+1] == (20 - Target[1])))||(((10<Stm32_Target_Arrange_temp_output_delet_point[i])&&(Stm32_Target_Arrange_temp_output_delet_point[i]<20)) && ((10<Stm32_Target_Arrange_temp_output_delet_point[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point[i+1]<20))))
					{
						Stm32_Target_Arrange_temp_output_delet_point[i]=0;
						Stm32_Target_Arrange_temp_output_delet_point[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point2[j++]= Stm32_Target_Arrange_temp_output_delet_point[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point2[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point2[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point2[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point2[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point2[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point2[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point2[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point2[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point2[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point2[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point2[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point2[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point2[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point2[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point2[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point2[15];
				 break;
			}
			break;
		}
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 2:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				//��һ����
			   case 1:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output_delet_point[i])&&(Stm32_Target_Arrange_temp_output_delet_point[i]<10)) && ((10<Stm32_Target_Arrange_temp_output_delet_point[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point[i+1]<20)))
					{
						if(( Stm32_Target_Arrange_temp_output_delet_point[i] != (20 - Target[0])) || (Stm32_Target_Arrange_temp_output_delet_point[i+1] != (20 - Target[1])))
						{
							Stm32_Target_Arrange_temp_output_delet_point[i]=0;
						    Stm32_Target_Arrange_temp_output_delet_point[i+1]=0;
						}
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point2[j++]= Stm32_Target_Arrange_temp_output_delet_point[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point2[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point2[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point2[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point2[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point2[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point2[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point2[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point2[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point2[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point2[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point2[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point2[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point2[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point2[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point2[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point2[15];
				break;
				case 2:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output_delet_point[i])&&(Stm32_Target_Arrange_temp_output_delet_point[i]<10)) && ((0<Stm32_Target_Arrange_temp_output_delet_point[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point[i+1]<10)))
					{
						if(( Stm32_Target_Arrange_temp_output_delet_point[i] != (20 - Target[0])) || (Stm32_Target_Arrange_temp_output_delet_point[i+1] != (20 - Target[1])))
						{
							Stm32_Target_Arrange_temp_output_delet_point[i]=0;
						    Stm32_Target_Arrange_temp_output_delet_point[i+1]=0;
						}
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point2[j++]= Stm32_Target_Arrange_temp_output_delet_point[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point2[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point2[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point2[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point2[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point2[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point2[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point2[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point2[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point2[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point2[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point2[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point2[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point2[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point2[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point2[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point2[15];
				 break;
			}
		break;
		}
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 3:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				//��һ����
			   case 1:
				  for(i=6;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output_delet_point[i])&&(Stm32_Target_Arrange_temp_output_delet_point[i]<10)) && ((10<Stm32_Target_Arrange_temp_output_delet_point[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point[i+1]<20)))
					{
						Stm32_Target_Arrange_temp_output_delet_point[i]=0;
						Stm32_Target_Arrange_temp_output_delet_point[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point2[j++]= Stm32_Target_Arrange_temp_output_delet_point[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point2[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point2[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point2[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point2[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point2[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point2[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point2[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point2[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point2[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point2[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point2[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point2[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point2[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point2[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point2[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point2[15];
				break;
				case 2:
				  for(i=6;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output_delet_point[i])&&(Stm32_Target_Arrange_temp_output_delet_point[i]<10)) && ((0<Stm32_Target_Arrange_temp_output_delet_point[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point[i+1]<10)))
					{
						Stm32_Target_Arrange_temp_output_delet_point[i]=0;
						Stm32_Target_Arrange_temp_output_delet_point[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point2[j++]= Stm32_Target_Arrange_temp_output_delet_point[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point2[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point2[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point2[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point2[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point2[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point2[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point2[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point2[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point2[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point2[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point2[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point2[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point2[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point2[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point2[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point2[15];

					  break;
			}
		  break;
	  }
   }
}
void Delete_quadrant_point_arrangement_third_point(int metrue, int Target[2])
{
	//meture��1Ϊ����򼺼٣�2Ϊ����,3Ϊ�м�
	int i,j;
	int quadrant;
	switch(metrue)
	{
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 1:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				
				//��һ����
			   case 1:
				   for(i=6;i<16;i=i+2)
				 {
					if((( Stm32_Target_Arrange_temp_output_delet_point2[i] == (20 - Target[0])) && (Stm32_Target_Arrange_temp_output_delet_point2[i+1] == (20 - Target[1])))||(((10<Stm32_Target_Arrange_temp_output_delet_point2[i])&&(Stm32_Target_Arrange_temp_output_delet_point2[i]<20)) && ((0<Stm32_Target_Arrange_temp_output_delet_point2[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point2[i+1]<10))))
					{
						Stm32_Target_Arrange_temp_output_delet_point2[i]=0;
						Stm32_Target_Arrange_temp_output_delet_point2[i+1]=0;
					}
				 }

				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point2[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point3[j++]= Stm32_Target_Arrange_temp_output_delet_point2[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point3[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point3[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point3[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point3[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point3[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point3[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point3[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point3[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point3[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point3[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point3[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point3[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point3[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point3[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point3[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point3[15];

				break;
			}
			break;
		}
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 2:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				//��һ����
			   case 1:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output_delet_point2[i])&&(Stm32_Target_Arrange_temp_output_delet_point2[i]<10)) && ((10<Stm32_Target_Arrange_temp_output_delet_point2[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point2[i+1]<20)))
					{
						if((Stm32_Target_Arrange_temp_output_delet_point2[i] != (20 - Target[0])) || (Stm32_Target_Arrange_temp_output_delet_point2[i+1] != (20 - Target[1])))
						{
							Stm32_Target_Arrange_temp_output_delet_point2[i]=0;
							Stm32_Target_Arrange_temp_output_delet_point2[i+1]=0;
						}
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point2[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point3[j++]= Stm32_Target_Arrange_temp_output_delet_point2[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point3[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point3[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point3[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point3[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point3[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point3[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point3[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point3[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point3[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point3[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point3[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point3[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point3[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point3[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point3[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point3[15];

				break;		  
			}
		break;
		}
		//����Ϊ��һ���ޣ�����Ϊ�ڶ�����
		case 3:
		{	
			 if(((10<Target[0])&&(Target[0]<20))&&((10<Target[1])&&(Target[1]<20)))
			{
				quadrant=2;
			}
			else if(((10<Target[0])&&(Target[0]<20))&&((0<Target[1])&&(Target[1]<10)))
			{
				quadrant=1;
			}
			switch(quadrant)
			{
				//��һ����
			   case 1:
				  for(i=0;i<16;i=i+2)
				 {
					if(((0<Stm32_Target_Arrange_temp_output_delet_point2[i])&&(Stm32_Target_Arrange_temp_output_delet_point2[i]<10)) && ((10<Stm32_Target_Arrange_temp_output_delet_point2[i+1])&&(Stm32_Target_Arrange_temp_output_delet_point2[i+1]<20)))
					{
						Stm32_Target_Arrange_temp_output_delet_point2[i]=0;
						Stm32_Target_Arrange_temp_output_delet_point2[i+1]=0;
					}
				 }
				    for(i=0,j=0;i<16;i++)
				{
					if( Stm32_Target_Arrange_temp_output_delet_point2[i] != 0)
					{
						Stm32_Target_Arrange_temp_output_delet_point3[j++]= Stm32_Target_Arrange_temp_output_delet_point2[i];
					}
				}
					  Stm32_Target1[0] = Stm32_Target_Arrange_temp_output_delet_point3[0];
					  Stm32_Target1[1] = Stm32_Target_Arrange_temp_output_delet_point3[1];
					  Stm32_Target2[0] = Stm32_Target_Arrange_temp_output_delet_point3[2];
					  Stm32_Target2[1] = Stm32_Target_Arrange_temp_output_delet_point3[3];
					  Stm32_Target3[0] = Stm32_Target_Arrange_temp_output_delet_point3[4];
					  Stm32_Target3[1] = Stm32_Target_Arrange_temp_output_delet_point3[5];
					  Stm32_Target4[0] = Stm32_Target_Arrange_temp_output_delet_point3[6];
					  Stm32_Target4[1] = Stm32_Target_Arrange_temp_output_delet_point3[7];
					  Stm32_Target5[0] = Stm32_Target_Arrange_temp_output_delet_point3[8];
					  Stm32_Target5[1] = Stm32_Target_Arrange_temp_output_delet_point3[9];
					  Stm32_Target6[0] = Stm32_Target_Arrange_temp_output_delet_point3[10];
					  Stm32_Target6[1] = Stm32_Target_Arrange_temp_output_delet_point3[11];
					  Stm32_Target7[0] = Stm32_Target_Arrange_temp_output_delet_point3[12];
					  Stm32_Target7[1] = Stm32_Target_Arrange_temp_output_delet_point3[13];
					  Stm32_Target8[0] = Stm32_Target_Arrange_temp_output_delet_point3[14];
					  Stm32_Target8[1] = Stm32_Target_Arrange_temp_output_delet_point3[15];
				break;
			}
		  break;
	  }
   }
}

void BFS(int map[21][21],int i,int j,int m,int n)
{
	map[i][j] = 2;
	for (i = 2; i < 100; i++)
	{
		add_nun(i);
	}
	route(map,i,j,m,n);
}
void add_nun(int length)
{
	int i,j;
	for (i = 0; i < 21; i++)
	{
		for (j = 0; j < 21; j++)
		{
			if(map[i][j] == length)
			{
					//������
					if(map[i][j-1]==0)
				{
					map[i][j-1] = length+1;
				}
				//������
					 if(map[i-1][j]==0)
				{
					map[i-1][j] = length+1;
				}
				//������
				 if(map[i][j+1]==0)
				{
					map[i][j+1] = length+1;
				}
					//������
				 if(map[i+1][j]==0)
				{
					map[i+1][j] = length+1;

				}
			}
		}
	}
}
void route(int map[21][21],int i,int j,int m,int n)
{
	int x;
	int route_length;
	route_length = map[m][n];
	mileage=( map[m][n]- 2);
	Total_mileage = (mileage+Total_mileage);
	BFS_map_original[m][n] = map[m][n];
	for(x=0;x<100;x++)
	{
		if( map[m][n] == route_length)
		{
				//������
				if(map[m][n-1]==route_length-1)
			{
				BFS_map_original[m][n-1] = map[m][n-1];
				n=n-1;
			}
			//������
				else if(map[m-1][n]==route_length-1)
			{
				BFS_map_original[m-1][n]=map[m-1][n];
				m=m-1;
			}
			//������
				else if(map[m][n+1]==route_length-1)
			{
				BFS_map_original[m][n+1]=map[m][n+1];
				n=n+1;
			}
				//������
				else if(map[m+1][n]==route_length-1)
			{
				BFS_map_original[m+1][n]=map[m+1][n];
				m=m+1;
			}
				route_length--;
		}
	}
}
void Judge_node(int map[21][21],int x,int y,int m,int n)
{
	int i,j;
	int Jode = 0;
	int route_length;
	
	for(route_length = map[x][y];route_length<map[m][n];route_length++)
	{
		for (i = 0; i < 21; i++)
		{
			for (j = 0; j < 21; j++)
			{
				if(BFS_map_original[i][j] == route_length)
	{
		
		//������
		 if(BFS_map_original[i-1][j]!=1 && BFS_map_original[i][j-1]!=1&& BFS_map_original[i-1][j]!=0 && BFS_map_original[i][j-1]!=0 )
		{
			if(BFS_map_original[i-1][j]>BFS_map_original[i][j-1])
			{
				Turn_temp[Jode++] = 2;
			}
			else if(BFS_map_original[i-1][j]<BFS_map_original[i][j-1])
			{
				Turn_temp[Jode++] = 3;
			}
		}
		//������
		else if(BFS_map_original[i-1][j]!=1 && BFS_map_original[i][j+1]!=1 && BFS_map_original[i-1][j]!=0 && BFS_map_original[i][j+1]!=0 )
		{
			if(BFS_map_original[i-1][j]>BFS_map_original[i][j+1])
			{
				Turn_temp[Jode++] = 3;
			}
			else if(BFS_map_original[i-1][j]<BFS_map_original[i][j+1])
			{
				Turn_temp[Jode++] = 2;
			}
		}
		//������
		else if(BFS_map_original[i+1][j]!=1 && BFS_map_original[i][j+1]!=1 && BFS_map_original[i+1][j]!=0 && BFS_map_original[i][j+1]!=0 )
		{
			if(BFS_map_original[i+1][j]>BFS_map_original[i][j+1])
			{
				Turn_temp[Jode++] = 2;
			}
			else if(BFS_map_original[i+1][j]<BFS_map_original[i][j+1])
			{
				Turn_temp[Jode++] = 3;
			}
		}
		//������
		else if(BFS_map_original[i+1][j]!=1 && BFS_map_original[i][j-1]!=1 && BFS_map_original[i+1][j]!=0 && BFS_map_original[i][j-1]!=0 )
		{
			if(BFS_map_original[i+1][j]>BFS_map_original[i][j-1])
			{
				Turn_temp[Jode++] = 3;
			}
			else if(BFS_map_original[i+1][j]<BFS_map_original[i][j-1])
			{
				Turn_temp[Jode++] = 2;
			}
		}
		else if((BFS_map_original[i+1][j]==0) || (BFS_map_original[i][j-1]==0) || (BFS_map_original[i][j+1]==0)||(BFS_map_original[i-1][j]==0))
		{
			if(BFS_map_original[i][j]!=BFS_map_original[x][y])
			{
				Turn_temp[Jode++] = 1;
			}

		}

	}
			}
		}
		
	}
}
