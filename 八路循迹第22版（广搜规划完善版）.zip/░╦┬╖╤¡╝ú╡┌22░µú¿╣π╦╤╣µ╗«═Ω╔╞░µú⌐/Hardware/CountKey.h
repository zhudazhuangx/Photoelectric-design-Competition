#ifndef __COUNTKEY_H
#define __COUNTKEY_H

void CountKey_Init(void);
uint16_t CountSensor_Get(void);

#endif
