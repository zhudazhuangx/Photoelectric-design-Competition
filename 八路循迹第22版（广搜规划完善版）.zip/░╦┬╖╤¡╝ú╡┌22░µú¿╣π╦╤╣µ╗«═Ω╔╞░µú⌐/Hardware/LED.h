#ifndef __LED_H
#define __LED_H


void LED_Init(void);
void Buzzer_Init(void);


void W_LED_ON(void);
void W_LED_OFF(void);

void R_LED_ON(void);
void R_LED_OFF(void);

void B_LED_ON(void);
void B_LED_OFF(void);

void RB_LED_OFF(void);

void Buzzer_ON(void);
void Buzzer_OFF(void);


#endif
