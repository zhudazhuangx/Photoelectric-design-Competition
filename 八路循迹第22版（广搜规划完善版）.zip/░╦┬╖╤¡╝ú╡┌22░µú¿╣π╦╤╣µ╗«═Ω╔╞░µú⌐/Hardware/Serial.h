#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>

void USART1_Init(void);
void OpenMV_Init(void);
void Laser_Init(void);

void Serial_SendByte(uint8_t Byte);


extern uint8_t color[2];
#endif
