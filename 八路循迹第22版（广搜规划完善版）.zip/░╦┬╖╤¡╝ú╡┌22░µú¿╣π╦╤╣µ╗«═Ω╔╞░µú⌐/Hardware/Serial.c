#include "stm32f10x.h"                  // Device header
#include "System.h"

uint16_t RxLine = 0;//ָ���

uint16_t Red=0;//Red=1�����췽����  |  Red=2�����췽α����
uint16_t Blue=0;//Blue=1������������ | Blue=2��������α����
uint8_t DataBuff[200];//ָ������
uint8_t Path_Flag;


unsigned char OpenMv_X,OpenMv_Y;

unsigned char Path1_data_Num,Path2_data_Num,Path3_data_Num,
			  Path4_data_Num,Path5_data_Num,Path6_data_Num,
			  Path7_data_Num,Path8_data_Num,Path9_data_Num;


uint8_t color[2]={0};
void USART1_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
}

void OpenMV_Init(void)
{
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	// GPIOBʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE); //����3ʱ��ʹ��
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate =115200;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART3, &USART_InitStructure);
	
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	USART_Cmd(USART3, ENABLE);
}

void Laser_Init(void)
{
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	// GPIOBʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE); //����3ʱ��ʹ��
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART2, &USART_InitStructure);
	
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	USART_Cmd(USART2, ENABLE);
}

void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}



int fputc(int ch, FILE *f)
{
	Serial_SendByte(ch);
	return ch;
}

void USART_Adjust(void)
{
	unsigned char data_Start_Num = 0; // ��¼����λ��ʼ�ĵط�
    unsigned char data_End_Num = 0; // ��¼����λ�����ĵط�
    unsigned char data_Num = 0; // ��¼����λ��
	unsigned char i=0;

    for(i=0;i<100;i++) 
    {

        if(DataBuff[i] == 0x5B)		//����λ
        {
            data_End_Num = i ;
            break;
        }
	}
		data_Num = data_End_Num;
		
		for(i=0;i<data_Num ;i++)
		{
			switch(Path_Flag)
			{
				case 1:	
						OpenMv_Target1[i]=DataBuff[data_Start_Num+i];
							Path1_data_Num=data_End_Num;break;
				
				case 2:	
						OpenMv_Target2[i]=DataBuff[data_Start_Num+i];
							Path2_data_Num=data_End_Num;break;
				
				case 3:	
						OpenMv_Target3[i]=DataBuff[data_Start_Num+i];
							Path3_data_Num=data_End_Num;break;
				
				case 4:	
						OpenMv_Target4[i]=DataBuff[data_Start_Num+i];
							Path4_data_Num=data_End_Num;break;
				
				case 5:	
						OpenMv_Target5[i]=DataBuff[data_Start_Num+i];
							Path5_data_Num=data_End_Num;break;
				
				case 6:	
						OpenMv_Target6[i]=DataBuff[data_Start_Num+i];
							Path6_data_Num=data_End_Num;break;
				
				case 7:	
						OpenMv_Target7[i]=DataBuff[data_Start_Num+i];
							Path7_data_Num=data_End_Num;break;
				
				case 8:	
						OpenMv_Target8[i]=DataBuff[data_Start_Num+i];
							Path8_data_Num=data_End_Num;break;
				
			}	
		}
		
			if	(Path_Flag==8)
			{
				Receive_State=1;
				
				OLED_ShowNum(2,1,OpenMv_Target1[0],1);OLED_ShowNum(2,2,OpenMv_Target1[1],1);
				OLED_ShowNum(2,4,OpenMv_Target2[0],1);OLED_ShowNum(2,5,OpenMv_Target2[1],1);
				OLED_ShowNum(2,7,OpenMv_Target3[0],1);OLED_ShowNum(2,8,OpenMv_Target3[1],1);
				OLED_ShowNum(2,10,OpenMv_Target4[0],1);OLED_ShowNum(2,11,OpenMv_Target4[1],1);
				OLED_ShowNum(3,1,OpenMv_Target5[0],1);OLED_ShowNum(3,2,OpenMv_Target5[1],1);
				OLED_ShowNum(3,4,OpenMv_Target6[0],1);OLED_ShowNum(3,5,OpenMv_Target6[1],1);
				OLED_ShowNum(3,7,OpenMv_Target7[0],1);OLED_ShowNum(3,8,OpenMv_Target7[1],1);
				OLED_ShowNum(3,10,OpenMv_Target8[0],1);OLED_ShowNum(3,11,OpenMv_Target8[1],1);

	}
}


float Transition(u8 High,u8 Low)
{

	short transition; //����ת�����м����
	
	transition=((High<<8)+Low); //����8λ�͵�8λ���ϳ�һ��16λ��short������
	return   	transition;  //��16���ƻ����10����				
}


void USART3_IRQHandler(void)
{
	static uint8_t USART3_RxState = 0;
	uint8_t USART3_RxData=0;
	switch(Receive_State)
	{
		case 0:{
	
								if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
								{
									USART3_RxData = USART_ReceiveData(USART3);

									if(USART3_RxState==0  && USART3_RxData==0x2C)  //0xFA֡ͷ��ʼ���ݽ��մ���
									{
										USART3_RxState=1;
										Path_Flag++;
										
									}
									else if(USART3_RxState==1)
									{
																				 
										DataBuff[RxLine++]= USART3_RxData;    //��ÿ�ν��յ������ݱ��浽��������
										if(USART3_RxData==0x5B)            //����֡β
										{
											
											USART_Adjust();//���ݽ���
											memset(DataBuff,0,sizeof(DataBuff));  //��ջ�������
											RxLine=0;  //��ս��ճ���
											USART3_RxState=0;
										}
									}
									USART_ClearITPendingBit(USART3, USART_IT_RXNE);
									}
						}
		case 2:
		{
			if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
					{
						if(Decelerate_Flag==1)
						{
							USART3_RxData = USART_ReceiveData(USART3);

							if(USART3_RxState==0  && USART3_RxData==0x3C)  //0xFA֡ͷ��ʼ���ݽ��մ���
							{
								USART3_RxState=1;										
							}
							else if(USART3_RxState==1)
							{
																				 
								DataBuff[RxLine++]= USART3_RxData;    //��ÿ�ν��յ������ݱ��浽��������
								if(USART3_RxData==0x6B)            //����֡β
									{
										
											
										for(int i=0;i<2;i++)
										{
											color[i]=DataBuff[i];
										}
											
//										printf("��ɫ");
//											
//										for(int i=0;i<2;i++)
//										{
//											printf("%d ",color[i]);
//										}
//										printf("\r\n");
										
										OLED_ShowNum(4,7,color[0],1);
										OLED_ShowNum(4,8,color[1],1);
										
										memset(DataBuff,0,sizeof(DataBuff));  //��ջ�������
										RxLine=0;  //��ս��ճ���
										USART3_RxState=0;
									}
											
								}
							}
								USART_ClearITPendingBit(USART3, USART_IT_RXNE);
					}
				}
		}

}

void USART2_IRQHandler(void)
{
	static uint8_t USART2_RxState = 0;
	uint8_t USART2_RxData=0;
	if (USART_GetITStatus(USART2, USART_IT_RXNE) == SET)
	{		
		if(Dist_ON_Flag==1)
		{			
			USART2_RxData = USART_ReceiveData(USART2);
			if(USART2_RxState==0  && USART2_RxData==0x01)  //0xFA֡ͷ��ʼ���ݽ��մ���
			{

				USART2_RxState=1;										
			}
				else if(USART2_RxState==1)
			{
																				 
				DataBuff[RxLine]= USART2_RxData;    //��ÿ�ν��յ������ݱ��浽��������
				RxLine++;
				if(RxLine== 6)            //�ж�λ��Ϊ7λ
				{
										
					Dist_mm = Transition(DataBuff[2],DataBuff[3]);
					
//					if(Dist_mm>500)Dist_mm=500;
						
					memset(DataBuff,0,sizeof(DataBuff));  //��ջ�������					
										
					RxLine=0;  //��ս��ճ���
					USART2_RxState=0;
				}
											
			}
		}
				USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}
}
