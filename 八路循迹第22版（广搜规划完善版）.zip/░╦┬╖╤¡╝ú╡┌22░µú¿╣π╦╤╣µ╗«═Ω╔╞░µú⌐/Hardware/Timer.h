#ifndef __TIMER_H
#define __TIMER_H

extern unsigned char TrackingData;
extern unsigned char data_arr[8];


extern unsigned long Delay;
extern unsigned int Turn_Delay,Buzzer_Delay;
extern unsigned long Flag_Bit_Delay;

void Timer_Init(void);
void MyDelay_ms(long delay);
#endif
