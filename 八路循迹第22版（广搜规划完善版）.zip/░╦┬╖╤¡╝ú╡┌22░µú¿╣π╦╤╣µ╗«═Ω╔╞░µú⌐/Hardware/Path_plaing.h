#ifndef __PATH_PLANING_H
#define __PATH_PLANING_H

//��·���滮
void Plaing(int path,int now_condition,int Own_color,int dot);
void mapping(void);
void abnomal(int path);
void Total_break(int path);
void Total_path_planning_break(int destination[2],int map[21][21]);
void Total_path_planning_myself_ultimate(int Target[2],int destination[2],int map[21][21],int sequence);
//��·���¼����������
void Path_planning_update(void);
//��openmv������תΪ��������
void extract_Treasure_Point(void);
//��������㴦����ͼ
void Go_through_all_the_points(void);
//���е�
void Coordinate_point_arrangement(void);
//�ŵ����躯��
void Delete_point_Path_planning(int sequence,int now_condition,int Own_color);
void Delete_quadrant_point_arrangement_first_point(int metrue, int Target[2]);
void Delete_quadrant_point_arrangement_second_point(int metrue, int Target[2]);
void Delete_quadrant_point_arrangement_third_point(int metrue, int Target[2]);
//����·���滮
void BFS(int map[21][21],int i,int j,int m,int n);
void route(int map[21][21],int i,int j,int m,int n);
void add_nun(int length);
//��ȡת����
void Judge_node(int map[21][21],int x,int y,int m,int n);



extern int OpenMv_Target1[2];
extern int OpenMv_Target2[2];
extern int OpenMv_Target3[2];
extern int OpenMv_Target4[2];//��
extern int OpenMv_Target5[2];
extern int OpenMv_Target6[2];
extern int OpenMv_Target7[2];
extern int OpenMv_Target8[2];
extern int ending;
extern int Turn_temp1[30];
extern int Turn_temp2[30];
extern int Turn_temp3[30];
extern int Turn_temp4[30];
extern int Turn_temp5[30];
extern int Turn_temp6[30];
extern int Turn_temp7[30];
extern int Turn_temp8[30];
extern int Turn_temp9[30];
extern int Turn_temp_break[30];
#endif

