#include "stm32f10x.h"                  // Device header
#include "Delay.h"

#define Tracking_PORT  GPIOD
#define Tracking_CLK GPIO_Pin_0
#define Tracking_DAT GPIO_Pin_1


void Tracking_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);

	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = Tracking_DAT;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(Tracking_PORT, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin =Tracking_CLK;
	GPIO_Init(Tracking_PORT, &GPIO_InitStructure);
}



unsigned char  Tracking_Read(void)
{
	uint8_t i,Data = 0;
	
	for (i = 0; i < 8; ++i) {
		
		GPIO_ResetBits(Tracking_PORT, Tracking_CLK);
		
		Delay_us(5); 
		
		Data |= GPIO_ReadInputDataBit(Tracking_PORT, Tracking_DAT) << i;
		
		GPIO_SetBits(Tracking_PORT, Tracking_CLK);
		
		Delay_us(5);
	}
	
	return Data;
}


