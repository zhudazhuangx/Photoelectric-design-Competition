#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Timer.h"

void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOD, GPIO_Pin_6);
	GPIO_ResetBits(GPIOC, GPIO_Pin_7);
	GPIO_SetBits(GPIOC, GPIO_Pin_5);

}

void Buzzer_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_ResetBits(GPIOA, GPIO_Pin_1);


}

void W_LED_ON(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_7);

}

void W_LED_OFF(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_7);

}

void R_LED_ON(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_8);

}

void R_LED_OFF(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_8);

}

void B_LED_ON(void)
{
	GPIO_SetBits(GPIOC, GPIO_Pin_9);

}

void B_LED_OFF(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_9);

}
void RB_LED_OFF(void)
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_9);
	GPIO_ResetBits(GPIOC, GPIO_Pin_8);

}




void Buzzer_ON(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_1);

}

void Buzzer_OFF(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_1);

}




