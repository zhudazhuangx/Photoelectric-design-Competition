#include "stm32f10x.h"// Device header

#include "Timer.h"
#include "System.h"

unsigned long Decelerate_Delay=700;
unsigned char TrackingData;
unsigned char data_arr[8] = {0};

unsigned long Delay,T_Counter,LED_Delay=400;

unsigned int Turn_Delay=500,Buzzer_Delay=50;

unsigned long Flag_Bit_Delay;

void Timer_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	
	TIM_InternalClockConfig(TIM2);
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Period = 1000 - 1;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72 - 1;
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
	
	TIM_ClearFlag(TIM2, TIM_FLAG_Update);
	TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM2, ENABLE);
}



void MyDelay_ms(long delay)
{
	Delay=delay;
	while(Delay);
}


void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		
		T_Counter++;
		if(T_Counter==1000)T_Counter=0;		//用于定时器计数
		
		
		Delay--;							//用于计算延时时间
		if(Delay<=0)Delay=0;
		
		if(LED_Delay==0)LED_Delay=400;
		
		

		if(Receive_State==1)	//串口接收地图标志位
		{
			
			Plaing(0,5,Camp_Flag,Interrupt_Flag);
			Plaing(1,5,Camp_Flag,Interrupt_Flag);

			Receive_State=2;
			
			Buzzer_Delay=200;
			Buzzer_Flag=1;
			
		}	
			
		if(Decelerate_Flag==2)
		{
			Decelerate_Delay--;
			if(Decelerate_Delay==0)
			{
				Decelerate_Delay=700;
				Decelerate_Flag=1;
			
			}
		
		}
		
//		if(Flag_Bit==1&&Decelerate_Flag==0)
//		{
//			Flag_Bit_Delay++;
//			if(Flag_Bit_Delay==1000)
//			{
//				Speed=28;
//				
//				Flag_Bit=0;
//				Flag_Bit_Delay=0;
//			}
//			
//		}

		
		
		if(LED_Flag==1)W_LED_ON();
		else	W_LED_OFF();
		
		
		if(Now_condition==1)	{	R_LED_ON();B_LED_OFF();	}
		
		if(Now_condition==2)	{	R_LED_ON();B_LED_ON();	}
									
		if(Now_condition==3)	{	B_LED_ON();R_LED_OFF();	}
		
		if(Now_condition==4)	{	R_LED_ON();B_LED_ON();	}
		
		
		
		
		if(Interrupt_Flag==2)	//中断线路标志
		{
			
			LED_Delay--;
			if(LED_Delay>200)	{	R_LED_ON();B_LED_OFF();	Buzzer_ON();}
			else				{	B_LED_ON();R_LED_OFF(); Buzzer_OFF();}
		}
		
		
		if(Buzzer_Flag==1)
		{
			Buzzer_ON();//蜂鸣器
			Buzzer_Delay--;
			if(Buzzer_Delay==0)
			{
				Buzzer_Flag=0;
				Buzzer_Delay=30;
				Buzzer_OFF();
			}
		}

			
		
		if(T_Counter%=10)	//
		{
			TrackingData=Tracking_Read();
			
			SEP_ALL_BIT8(TrackingData, 
				data_arr[0], // ̽ͷ1
				data_arr[1], // ̽ͷ2 
				data_arr[2], // ̽ͷ3
				data_arr[3], // ̽ͷ4
				data_arr[4], // ̽ͷ5
				data_arr[5], // ̽ͷ6
				data_arr[6], // ̽ͷ7
				data_arr[7]  // ̽ͷ8
			);
		}
		
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}
