#include "stm32f10x.h"                  // Device header
#include "Path.h"

#include "System.h"

unsigned int Path;			//��·��־λ
unsigned int Speed;
unsigned char Node_Num;		//�ڵ���
unsigned char Node_Data;	//�ڵ�����


float Tracking_Error;
float Tracking_Last_Error;
unsigned char Tracking_Flag;


float Tracking_limit_float(float insert,float low,float high)
{
    if (insert < low)			return low;
        
    else if (insert > high) 	return high;
       
    else	return insert;
        	
}

int Tracking_PD(void)
{
	int Output;
	float Kp=10 ,Ki=0, Kd=-1;
	float P, I, D;
	
	P =	 Tracking_Error;
	I += Tracking_Error;
	D = Tracking_Error-Tracking_Last_Error;
	
	Output =Kp*P+Ki*I+Kd*D;
	
	Output=Tracking_limit_float(Output,-30,30);
	
	Tracking_Last_Error=Tracking_Error;
	
	return Output;
	
}
void Line_Repair(void)//����ѭ��
{	
		if(	data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==0&&
			data_arr[4]==0&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	//ǰ��
		{
			Tracking_Error=0;
		}
	
//11101111
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==0&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=1;
		}
//11001111		
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==0&&data_arr[3]==0&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=2;
		}
//11011111
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==0&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=4;
		}
//10011111
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==0&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=6;
		}
//10111111
		else if(data_arr[0]==1&&data_arr[1]==0 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=8;
		}
//00111111
		else if(data_arr[0]==0&&data_arr[1]==0 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=10;
		}
//01111111
		else if(data_arr[0]==0&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )
		{
			Tracking_Error=12;
		}
	
//11110111	
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==0&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=-1;
		}
//11110011	
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==0&&data_arr[5]==0 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=-2;
		}		
//11111011	
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==0 && data_arr[6]==1&&data_arr[7]==1 )	
		{
			Tracking_Error=-4;
		}
//11111001	
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==0 && data_arr[6]==0&&data_arr[7]==1 )	
		{
			Tracking_Error=-6;
		}
//11111101	
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==0&&data_arr[7]==1 )	
		{
			Tracking_Error=-8;
		}
//11111100	
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==0&&data_arr[7]==0 )	
		{
			Tracking_Error=-10;
		}		
//11111110	
		else if(data_arr[0]==1&&data_arr[1]==1 && data_arr[2]==1&&data_arr[3]==1&&
				data_arr[4]==1&&data_arr[5]==1 && data_arr[6]==1&&data_arr[7]==0 )	
		{
			Tracking_Error=-12;
		}	
		
		Repair_Run(Speed-Tracking_PD(),Speed+Tracking_PD());	

			
}

void Car_Left_Turn_T(void)	//ԭ����ת
{
	Car_Left_angle(45);
	MyDelay_ms(20);
	while(data_arr[4]==0||data_arr[3]==0);
	MyDelay_ms(500);
	while(!(data_arr[3]==0&&data_arr[2]==0)); 
	
	Car_Right_angle(30);
	MyDelay_ms(40);
		
}

void Car_Left_Turn(void)	//ԭ����ת
{
	Dist_ON_Flag=0;
	Car_Left_angle(45);
	MyDelay_ms(20);
	while(data_arr[4]==0||data_arr[3]==0);
	while(!(data_arr[3]==0&&data_arr[2]==0)); 
	
	Car_Right_angle(30);
	MyDelay_ms(40);
	Dist_ON_Flag=1;
		
}

void Car_Right_Turn(void)
{
	Dist_ON_Flag=0;
	
	Car_Right_angle(45);
	MyDelay_ms(20);
	while(data_arr[4]==0|| data_arr[3]==0);
	while(!(data_arr[4]==0&&data_arr[5]==0));
	
	Car_Left_angle(30);
	MyDelay_ms(40);
	
	Dist_ON_Flag=1;
			
}



void Car_Strike(void)
{
	Speed=28;

	while(TrackingData!=255)
	{
		Buzzer_Flag=1;
		Line_Repair();
	}
	
	Car_Left_angle(45);
	MyDelay_ms(50);
	while(!(data_arr[3]==0 &&data_arr[2]==0));
	Car_Right_angle(30);
	MyDelay_ms(50);
		
}


void Clear_Flag(void)	
{
	Speed=28;
	Decelerate_Flag=0;
	Node_Num=0;
	LED_Flag=0;
	RB_LED_OFF();
	memset(color,0,sizeof(color));  

}

void Unusual_Status(void)
{
	
	Speed=28;
	Decelerate_Flag=0;
	Node_Num=0;
	LED_Flag=0;
	
	Plaing(Path+1,Now_condition,Camp_Flag,Interrupt_Flag);
	
}

int Get_Node_data(unsigned char Node_Num)
{
	unsigned char data;
	
	if(Interrupt_Flag==1)
	{
		switch(Path)
		{
			
			case 0:		data=Turn_temp1[Node_Num];break;

			case 1:		data=Turn_temp2[Node_Num];break;
					
			case 2:		data=Turn_temp3[Node_Num];break;
						
			case 3:		data=Turn_temp4[Node_Num];break;	
				
			case 4:		data=Turn_temp5[Node_Num];break;	
			
			case 5:		data=Turn_temp6[Node_Num];break;
						
			case 6:		data=Turn_temp7[Node_Num];break;		
				
			case 7:		data=Turn_temp8[Node_Num];break;
			
			case 8:		data=Turn_temp9[Node_Num];break;
		
							
		}
	}
	
	else if(Interrupt_Flag==2)	data=Turn_temp_break[Node_Num];
	
	return	data;
}



void Node_Estimate(void)
{
	
	Node_Data=Get_Node_data(Node_Num);
	
	Node_Num++;	
	
	switch(Node_Data)
	{
		case 3:	Car_Right_Turn();break;
			
		case 2:	Car_Left_Turn();break;
			
		case 1:	Car_Run(Speed);	break;
				
		case 0:
				if(Ending_Flag==1)	//�������е㣬ͣ���յ�
				{
					
					Buzzer_Flag=1;
					Buzzer_Delay=1000;
					while(1)
					{	
						Car_Stop();
					}
				}
				else
				{
					Car_Left_Turn_T();
					Node_Num=0;
					RB_LED_OFF();
					Speed=30;
					if(Decelerate_Flag)	
					{
						Path++;
						Decelerate_Flag=0;
						LED_Flag=0;
						Interrupt_Flag=1;
						Plaing(Path+1,0,Camp_Flag,Interrupt_Flag);
					}
				}	
	}
		
}

void Path_test(void) 
{
	if((data_arr[7]==0 &&data_arr[6]==0&&data_arr[5]==0&&data_arr[4]==0)||(data_arr[3]==0&& data_arr[2]==0&&data_arr[1]==0&&data_arr[0]==0))
	{
		if((data_arr[7]==0 &&data_arr[6]==0)||(data_arr[1]==0&&data_arr[0]==0))
		{
			Buzzer_Flag=1;
			Dist_Flag=0;
			
			if(Get_Node_data(Node_Num)==1)
			{
				Car_Run(Speed);
				Node_Num++;
			}
			else
			{
				Car_Back(40);
				MyDelay_ms(50);
				Node_Estimate();
					
			}
			
			while((data_arr[7]==0 &&data_arr[6]==0)||( data_arr[1]==0 && data_arr[0]==0));
			
			
			
			//����һ��·����Ϣ�ж�
			if(Get_Node_data(Node_Num)==0)	
			{
				if(ending!=1)
				{	
					Speed=20;
					LED_Flag=1;
					Decelerate_Flag=2;//��0.5s����ʶ��
				}
				else if (ending==1)
				{
					Ending_Flag=1; 
					Speed=50;
				}
			
	
			}
			else if(Get_Node_data(Node_Num)!=1 && Get_Node_data(Node_Num-1)==1 )
			{
					Speed=30;
			}
			else if(Get_Node_data(Node_Num)==1)	
			{		
					Speed=45;
			}
			
			else 
			{
				Speed=35;

			}
					
		}
	}
	
	else if((TrackingData==255&&Decelerate_Flag==1)||(TrackingData==255&&Ending_Flag==1))
	{

		Node_Estimate();
	}
	

	else Line_Repair();
	
}




