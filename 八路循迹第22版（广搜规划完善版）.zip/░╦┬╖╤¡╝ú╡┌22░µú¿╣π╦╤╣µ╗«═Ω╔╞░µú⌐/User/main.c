#include "stm32f10x.h"                  // Device header
#include "System.h"

uint8_t KeyNum,Start_Flag;

int main(void)
{
	
	System_Init();
	
	

	Interrupt_Flag=1;		//Ĭ��Ϊ������ʹ������Ϊ�췽
	Camp_Flag=1;
	

	Receive_State=0;//���ܱ�־λ
	
	Decelerate_Flag=0;//���ٱ�־λ
	LED_Flag=0;

//	Plaing(0,5,Camp_Flag,Interrupt_Flag);
//	Plaing(1,5,Camp_Flag,Interrupt_Flag);
	
	Speed=35;
	
	OLED_ShowString(1,1,"coordinate:");
	OLED_ShowString(4,1,"Color:");
	
	while (1)
	{

		if(Start_Flag==0)
		{
			if(Camp_Flag==1){R_LED_ON();B_LED_OFF();}
			else if(Camp_Flag==2){B_LED_ON();R_LED_OFF();}
	
			
			KeyNum=Key_GetNum();
			if(KeyNum==1)
			{	
				Start_Flag=1;
				RB_LED_OFF();
//				OpenMV_Reset();
				
			}
			
			if(KeyNum==2)
			{	
				if(Camp_Flag==1)Camp_Flag=2;
				else 	Camp_Flag=1;
				
			}

		}
		
		else if(Start_Flag==1)
			{

				if((color[0]!=0||color[1]!=0)&&Decelerate_Flag==1)
				{
					
					Buzzer_Flag=1;
					
					Decelerate_Flag=0;
					Interrupt_Flag=1;
					Now_condition=0;
			
					
					if(color[0]==1)			Now_condition=1;	//����
					else if(color[0]==2)	Now_condition=2;	//���
					else if(color[1]==1)	Now_condition=3;	//����
					else if(color[1]==2)	Now_condition=4;	//����
					
					
					if((Now_condition==1&&Camp_Flag==1)||(Now_condition==3&&Camp_Flag==2))
					{	

						Car_Strike();
						Treasure_Num++;
						
					}
					else	Car_Left_Turn();
					
	
					Path++;
					Plaing(Path+1,Now_condition,Camp_Flag,Interrupt_Flag);
					Now_condition=0;
					
					Clear_Flag();
				}	

				else if(Dist_mm<150&&Dist_mm>10)
				{
					if(Dist_Flag==0)
					{
						Car_Back(40);
						MyDelay_ms(50);
						Dist_Flag++;
					}
					
					Car_Stop();
					Delay=2000;
					while(Delay)
					{
						if(Key_GetNum()==1)
						{
							Unusual_Status();
							while(Key_GetNum()!=1);
						}
					}
					
				}

				else Path_test();
				
			}
	}
}


