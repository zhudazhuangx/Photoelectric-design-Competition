#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>
extern uint8_t Glag;


void Serial_Init(void);
void USART3_Init(void);

void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void shou(void);

extern  uint8_t Path1[100];
extern 	uint8_t Path2[100];
extern  uint8_t Path3[100];
extern  uint8_t Path4[100];
extern  uint8_t Path5[100];
extern  uint8_t Path6[100];
extern  uint8_t Path7[100];
extern  uint8_t Path8[100];
extern  uint8_t Path9[100];
#endif
