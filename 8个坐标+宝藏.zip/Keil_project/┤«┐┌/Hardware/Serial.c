#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

static uint8_t Receive_State = 0;
uint16_t RxLine = 0;//ָ���
uint8_t  color_state=0;//�ж���ɫ
uint8_t Red=0;//Red=1�����췽����
uint8_t Blue=0;//Blue=1������������
uint8_t DataBuff[200];//ָ������
uint8_t Path_Flag;
uint8_t Glag=0;
unsigned char Path1_data_Num,Path2_data_Num,Path3_data_Num,
			  Path4_data_Num,Path5_data_Num,Path6_data_Num,
			  Path7_data_Num,Path8_data_Num,Path9_data_Num;

uint8_t Path1[100]={0};
uint8_t Path2[100]={0};
uint8_t Path3[100]={0};
uint8_t Path4[100]={0};
uint8_t Path5[100]={0};
uint8_t Path6[100]={0};
uint8_t Path7[100]={0};
uint8_t Path8[100]={0};
//uint8_t Path9[100]={0};
uint8_t color[4]={0};
void USART3_Init(void);
void Serial_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
	USART3_Init();
}

void USART3_Init(void)
{
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	// GPIOBʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE); //����3ʱ��ʹ��
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART3, &USART_InitStructure);
	
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	USART_Cmd(USART3, ENABLE);
}

void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

void Serial_SendArray(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)
	{
		Serial_SendByte(Array[i]);
	}
}

void Serial_SendString(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)
	{
		Serial_SendByte(String[i]);
	}
}


int fputc(int ch, FILE *f)
{
	Serial_SendByte(ch);
	return ch;
}
void shou(void)
{

		Serial_SendArray(Path1, Path1_data_Num);
		Serial_SendArray(Path2, Path2_data_Num);
		Serial_SendArray(Path3, Path3_data_Num);
		Serial_SendArray(Path4, Path4_data_Num);
		Serial_SendArray(Path5, Path5_data_Num);
		Serial_SendArray(Path6, Path6_data_Num);
		Serial_SendArray(Path7, Path7_data_Num);
		Serial_SendArray(Path8, Path8_data_Num);
//		Serial_SendArray(Path9, Path9_data_Num);


}
void USART_Adjust(void)
{
	unsigned char data_Start_Num = 0; // ��¼����λ��ʼ�ĵط�
    unsigned char data_End_Num = 0; // ��¼����λ�����ĵط�
    unsigned char data_Num = 0; // ��¼����λ��
	unsigned char i=0;

    for(i=0;i<100;i++) 
    {

        if(DataBuff[i] == 0x5B)		//����λ
        {
            data_End_Num = i ;
            break;
        }
	}
		data_Num = data_End_Num;
		
		for(i=0;i<data_Num ;i++)
		{
			switch(Path_Flag)
			{
				case 1:	
						Path1[i]=DataBuff[data_Start_Num+i];
							Path1_data_Num=data_End_Num;break;
				
				case 2:	
						Path2[i]=DataBuff[data_Start_Num+i];
							Path2_data_Num=data_End_Num;break;
				
				case 3:	
						Path3[i]=DataBuff[data_Start_Num+i];
							Path3_data_Num=data_End_Num;break;
				
				case 4:	
						Path4[i]=DataBuff[data_Start_Num+i];
							Path4_data_Num=data_End_Num;break;
				
				case 5:	
						Path5[i]=DataBuff[data_Start_Num+i];
							Path5_data_Num=data_End_Num;break;
				
				case 6:	
						Path6[i]=DataBuff[data_Start_Num+i];
							Path6_data_Num=data_End_Num;break;
				
				case 7:	
						Path7[i]=DataBuff[data_Start_Num+i];
							Path7_data_Num=data_End_Num;break;
				
				case 8:	
						Path8[i]=DataBuff[data_Start_Num+i];
							Path8_data_Num=data_End_Num;break;
				
//				case 9:	
//						Path9[i]=DataBuff[data_Start_Num+i];
//							Path9_data_Num=data_End_Num;break;
			}	
		}
		
			if	(Path_Flag==8)
			{
				Receive_State=1;
				Glag=1;			
			}

}

void USART_color(void)
{
	
}



void USART3_IRQHandler(void)
{
	static uint8_t RxState = 0;
	uint8_t RxData=0;
	switch(Receive_State)
	{
		case 0:{
	
								if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
								{
									RxData = USART_ReceiveData(USART3);

									if(RxState==0  && RxData==0x2C)  //0xFA֡ͷ��ʼ���ݽ��մ���
									{
										RxState=1;
										Path_Flag++;
										
									}
									else if(RxState==1)
									{
																				 
										DataBuff[RxLine++]= RxData;    //��ÿ�ν��յ������ݱ��浽��������
										if(RxData==0x5B)            //����֡β
										{
											
											USART_Adjust();//���ݽ���
											memset(DataBuff,0,sizeof(DataBuff));  //��ջ�������
											RxLine=0;  //��ս��ճ���
											RxState=0;
										}
									}
									USART_ClearITPendingBit(USART3, USART_IT_RXNE);
									}
						}
		case 1:
		{
			if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
								{
									RxData = USART_ReceiveData(USART3);

									if(RxState==0  && RxData==0x3C)  //0xFA֡ͷ��ʼ���ݽ��մ���
									{
										RxState=1;
										Path_Flag++;
										
									}
									else if(RxState==1)
									{
																				 
										DataBuff[RxLine++]= RxData;    //��ÿ�ν��յ������ݱ��浽��������
										if(RxData==0x6B)            //����֡β
										{
											
											USART_color();//���ݽ���
											memset(DataBuff,0,sizeof(DataBuff));  //��ջ�������
											RxLine=0;  //��ս��ճ���
											RxState=0;
										}
											
									}
									USART_ClearITPendingBit(USART3, USART_IT_RXNE);
									}
						}
		}
}
